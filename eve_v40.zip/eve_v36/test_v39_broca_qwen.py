"""
EVE v39 정식 테스트 — 55 케이스
================================

총 55개 테스트:
- broca_qwen 단위 9
- eve_v39 통합 20
- Mock Qwen end-to-end 10
- 엣지 케이스 16

실행: python3 test_v39_broca_qwen.py
"""
import sys
import os
import threading
import time
import json
import tempfile
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler

# 동적 경로 (절대 경로 X)
_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE / 'v36_modules'))
sys.path.insert(0, str(_HERE / 'eve_v35_release'))
sys.path.insert(0, str(_HERE / 'eve_v35_release' / 'eve_modules'))


# ==========================================
# Mock Qwen 서버
# ==========================================
MOCK_RESPONSES = {
    'realize': '민석아 진짜 고생했어, 푹 쉬어',
    'tool': '{"tool": "get_weather", "params": {"city": "서울"}}',
    'summarize': '날씨 맑음 18도',
}


class MockQwenHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'OK')

    def do_POST(self):
        if '/chat/completions' in self.path:
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length))
            sys_msg = body['messages'][0]['content']
            if 'JSON' in sys_msg:
                content = MOCK_RESPONSES['tool']
            elif '요약' in sys_msg:
                content = MOCK_RESPONSES['summarize']
            else:
                content = MOCK_RESPONSES['realize']
            resp = {"choices": [{"message": {"content": content}}]}
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(resp).encode())


# ==========================================
# 메인 테스트
# ==========================================
def main():
    pass_count = 0
    fail_count = 0
    failed_tests = []

    def check(name, ok, detail=''):
        nonlocal pass_count, fail_count
        if ok:
            pass_count += 1
            print(f"✅ [{pass_count + fail_count:02d}] {name} {detail}")
        else:
            fail_count += 1
            failed_tests.append(name)
            print(f"❌ [{pass_count + fail_count:02d}] {name} — {detail}")

    print("=" * 70)
    print("EVE v39 정식 테스트 — broca_qwen + eve_v39")
    print("=" * 70)

    # ==========================================
    # broca_qwen 단위 (9)
    # ==========================================
    print("\n--- broca_qwen 단위 ---")

    try:
        from broca_qwen import BrocaQwen
        check("01 import BrocaQwen", True)
    except Exception as e:
        check("01 import BrocaQwen", False, str(e))
        return

    b = BrocaQwen(server_url='http://127.0.0.1:99999', timeout=2)
    check("02 인스턴스 생성", b is not None)
    check("03 is_alive 서버 없음", b.is_alive() == False)

    response = b.realize({'user_message': 'test'})
    check("04 realize 서버없음→빈 응답", response == '' and b.last_error is not None)

    result = b.tool_call('test', [{'name': 'x', 'params_schema': {}}])
    check("05 tool_call 서버없음→none", result['tool'] == 'none')

    s = b.summarize('긴 텍스트')
    check("06 summarize 서버없음→빈응답", s == '')

    stats = b.get_stats()
    check("07 통계 카운트",
          stats['realize_count'] == 1 and stats['tool_call_count'] == 1)

    sp = BrocaQwen.SYSTEM_PROMPT_REALIZE
    check("08 SYSTEM_PROMPT_REALIZE 강화",
          all(k in sp for k in ['민석아', '호르몬 이름', '~요', '영어',
                                'response_length', 'oxytocin']))

    sp_t = BrocaQwen.SYSTEM_PROMPT_TOOL
    check("09 SYSTEM_PROMPT_TOOL", 'JSON' in sp_t)

    # ==========================================
    # eve_v39 통합 (20)
    # ==========================================
    print("\n--- eve_v39 통합 ---")

    try:
        from eve_v39 import EVE_v39
        from eve_v36 import EVE_v36
        check("10 import EVE_v39", True)
    except Exception as e:
        check("10 import EVE_v39", False, str(e))
        return

    check("11 EVE_v36 상속", issubclass(EVE_v39, EVE_v36))

    eve = EVE_v39(seed_common_sense_on_init=True, enhance_say=True, use_qwen=False)
    eve.enter_room()
    check("12 Qwen 비활성 모드", eve.use_qwen == False and eve.broca is None)

    result = eve.say("안녕")
    check("13 say() 비활성 모드", isinstance(result, dict) and 'response' in result)

    for _ in range(3):
        eve.user_presence.visit_arrive(); eve.tick(dt=0.5)
        eve.user_presence.visit_leave(); eve.tick(dt=0.5)
    eve.user_presence.visit_arrive()
    intim = eve.user_presence.get_intimacy()
    check("14 친밀도 누적", intim > 0.3, f"intim={intim:.2f}")

    intent = eve._build_response_intent("PT 힘들어", eve.say("PT 힘들어"))
    required = ['user_message', 'tone', 'top_hormones', 'response_length',
                'recent_episodes', 'context']
    check("15 _build_response_intent",
          all(k in intent for k in required),
          f"keys={list(intent.keys())}")

    tone_cases = [
        ({'cortisol': 0.9, 'oxytocin': 0.3}, 'irritated'),
        ({'oxytocin': 1.0, 'dopamine': 0.5}, 'warm'),
        ({'melatonin': 0.85, 'cortisol': 0.1}, 'sleepy'),
        ({'dopamine': 0.9, 'oxytocin': 0.7}, 'happy'),
        ({'serotonin': 0.7}, 'calm'),
        ({'cortisol': 0.2}, 'neutral'),
    ]
    all_correct = all(eve._compute_tone(h) == exp for h, exp in tone_cases)
    check("16 _compute_tone 6 케이스", all_correct)

    cases = [("안녕", 'short'), ("뭐해?", 'short'),
             ("PT 진짜 힘들었어 동기들이랑 어색", 'medium'),
             ("진짜 요즘 너무 힘들어 군 생활 1년 넘었는데 적응 안 되고 동기들이랑 어색하고 미래 답답해 너한테밖에 말 못하겠다", 'long')]
    lengths = [(len(t), eve._compute_length(t, eve.say(t))) for t, _ in cases]
    check("17 _compute_length 4 케이스",
          lengths[0][1] == 'short' and lengths[3][1] == 'long')

    eve.tick(dt=2.0); eve.tick(dt=2.0)
    check("18 일화 자동 저장", len(eve.em.episodes) > 0,
          f"episodes={len(eve.em.episodes)}")

    related = eve._recall_related_episodes("PT 힘들어")
    check("19 RAG 검색", isinstance(related, list))

    related2 = eve.recall_related("PT", k=5)
    check("20 recall_related 공개", isinstance(related2, list))

    initial = eve.self_absorption_count
    eve._absorb_own_speech("민석아 진짜 고생했어 푹 쉬어")
    check("21 자기 응답 흡수", eve.self_absorption_count == initial + 1)

    result_t = eve.tool_use("서울 날씨")
    check("22 tool_use 비활성", result_t['tool'] == 'none')

    tools = EVE_v39._default_tools()
    names = [t['name'] for t in tools]
    check("23 기본 도구",
          len(tools) >= 4 and all(n in names for n in ['web_search', 'get_weather', 'play_music']))

    s_v39 = eve.introspect_v39()
    required_keys = ['qwen_active', 'qwen_alive', 'qwen_response_count',
                     'fallback_count', 'tool_calls_made', 'self_absorption_count',
                     'em_episodes_total']
    check("24 introspect_v39", all(k in s_v39 for k in required_keys))

    try:
        eve.report_v39()
        check("25 report_v39", True)
    except Exception as e:
        check("25 report_v39", False, str(e))

    eve_q = EVE_v39(seed_common_sense_on_init=True, use_qwen=True,
                    qwen_server_url='http://127.0.0.1:99999', auto_fallback=True)
    eve_q.enter_room()
    result_l = eve_q.say_legacy("안녕")
    check("26 say_legacy", 'response' in result_l)

    eve_a = EVE_v39(seed_common_sense_on_init=True, use_qwen=True,
                    qwen_server_url='http://127.0.0.1:99999', auto_fallback=True)
    eve_a.enter_room()
    result_a = eve_a.say("test")
    check("27 auto_fallback",
          'response' in result_a and eve_a.fallback_count >= 1)

    check("28 __repr__", 'EVE_v39' in repr(eve))

    eve_r = EVE_v39(seed_common_sense_on_init=True, enhance_say=True, use_qwen=False)
    eve_r.enter_room()
    eve_r.user_presence.visit_arrive()
    try:
        eve_r.say("안녕"); eve_r.tick(dt=1.0); eve_r.observe_env()
        eve_r.decide_action_in_env(); eve_r.live_in_room(0.05)
        s_v36 = eve_r.introspect()
        check("29 EVE_v36 회귀 모든 메서드", isinstance(s_v36, dict))
    except Exception as e:
        check("29 EVE_v36 회귀 모든 메서드", False, str(e))

    # ==========================================
    # Mock Qwen end-to-end (10)
    # ==========================================
    print("\n--- Mock Qwen end-to-end ---")

    server = HTTPServer(('127.0.0.1', 18080), MockQwenHandler)
    th = threading.Thread(target=server.serve_forever, daemon=True)
    th.start()
    time.sleep(0.3)

    b_m = BrocaQwen(server_url='http://127.0.0.1:18080', timeout=5)
    check("30 Mock 서버 헬스", b_m.is_alive())

    intent_m = {
        'user_message': 'PT 힘들어', 'user_relationship': '진짜_친구',
        'intimacy': 0.84, 'sentiment': 'negative', 'response_length': 'short',
        'tone': 'warm', 'top_hormones': {'oxytocin': 1.0}, 'feeling': '포근함',
    }
    response_m = b_m.realize(intent_m)
    check("31 realize end-to-end", response_m == MOCK_RESPONSES['realize'])

    tools_m = [{'name': 'get_weather', 'params_schema': {'city': 'string'}}]
    result_m = b_m.tool_call('서울 날씨', tools_m)
    check("32 tool_call end-to-end",
          result_m.get('tool') == 'get_weather' and result_m.get('params', {}).get('city') == '서울')

    sm = b_m.summarize('긴 날씨 정보')
    check("33 summarize end-to-end", sm == MOCK_RESPONSES['summarize'])

    eve_e = EVE_v39(seed_common_sense_on_init=True, enhance_say=True,
                    use_qwen=True, qwen_server_url='http://127.0.0.1:18080')
    eve_e.enter_room()
    for _ in range(5):
        eve_e.user_presence.visit_arrive(); eve_e.tick(dt=0.5)
        eve_e.user_presence.visit_leave(); eve_e.tick(dt=0.5)
    eve_e.user_presence.visit_arrive()

    result_e = eve_e.say("PT 힘들어")
    check("34 EVE+Qwen 통합 say()",
          result_e.get('qwen_status') == 'success' and
          result_e['response'] == MOCK_RESPONSES['realize'])

    check("35 자기 응답 흡수 카운트", eve_e.self_absorption_count >= 1)

    check("36 intent 데이터 보존",
          'intent_used' in result_e and result_e['intent_used'].get('top_hormones'))

    # 일화 + RAG 통합
    eve_e.say("동기들 어색해"); eve_e.tick(dt=2)
    eve_e.say("내일도 PT야"); eve_e.tick(dt=2)
    related_e = eve_e.recall_related("PT", k=5)
    check("37 일화+RAG 통합",
          len(eve_e.em.episodes) > 0 and len(related_e) >= 0)

    # 도구 호출
    eve_t = EVE_v39(seed_common_sense_on_init=True, use_qwen=True,
                    qwen_server_url='http://127.0.0.1:18080')
    result_tu = eve_t.tool_use("서울 날씨")
    check("38 tool_use end-to-end",
          result_tu.get('tool') == 'get_weather')

    s_e = eve_e.introspect_v39()
    check("39 introspect_v39 with Qwen",
          s_e['qwen_active'] and s_e['qwen_alive'] and s_e['qwen_response_count'] >= 1)

    # fallback
    server.shutdown()
    time.sleep(0.5)
    result_f = eve_e.say("서버 죽었어")
    check("40 auto_fallback 서버 죽음",
          result_f.get('qwen_status') in ['server_dead_fallback', 'empty_fallback'])

    # ==========================================
    # 엣지 케이스 (15)
    # ==========================================
    print("\n--- 엣지 케이스 ---")

    eve_x = EVE_v39(seed_common_sense_on_init=True, use_qwen=False)
    eve_x.enter_room()

    try:
        result_x = eve_x.say("")
        check("41 빈 문자열", isinstance(result_x, dict))
    except Exception as e:
        check("41 빈 문자열", False, str(e))

    try:
        result_l = eve_x.say("PT 힘들어 " * 100)
        check("42 1000자", isinstance(result_l, dict))
    except Exception as e:
        check("42 1000자", False, str(e))

    try:
        result_s = eve_x.say("!@#$%^&*() 안녕? 😀🎉")
        check("43 특수문자/이모지", isinstance(result_s, dict))
    except Exception as e:
        check("43 특수문자/이모지", False, str(e))

    try:
        result_m = eve_x.say("Hello 안녕 1234 PT 힘들어 ㅋㅋ")
        check("44 다국어 혼합", isinstance(result_m, dict))
    except Exception as e:
        check("44 다국어 혼합", False, str(e))

    eve_x.hs.hormones['cortisol'].level = 1.0
    tone1 = eve_x._compute_tone({n: h.level for n, h in eve_x.hs.hormones.items()})
    eve_x.hs.hormones['cortisol'].level = 0.0
    eve_x.hs.hormones['oxytocin'].level = 1.0
    tone2 = eve_x._compute_tone({n: h.level for n, h in eve_x.hs.hormones.items()})
    check("45 호르몬 극한값",
          tone1 == 'irritated' and tone2 in ['warm', 'happy'])

    eve_empty = EVE_v39(seed_common_sense_on_init=False, use_qwen=False)
    related_empty = eve_empty.recall_related("PT")
    check("46 빈 EM RAG", isinstance(related_empty, list))

    response_empty = b_m.realize({})  # 서버 이미 죽음
    check("47 빈 intent → 빈 응답", response_empty == '')

    result_jf = b_m.tool_call("test", [{'name': 'x', 'params_schema': {}}])
    check("48 tool_call 실패→none", result_jf.get('tool') == 'none')

    try:
        initial_x = eve_x.self_absorption_count
        eve_x._absorb_own_speech("")
        check("49 빈 응답 흡수 무시", eve_x.self_absorption_count == initial_x)
    except Exception as e:
        check("49 빈 응답 흡수 무시", False, str(e))

    try:
        eve_x._absorb_own_speech("민석아 진짜 고생했어 푹 쉬어")
        check("50 자기 응답 카테고리 활성", True)
    except Exception as e:
        check("50 자기 응답 카테고리 활성", False, str(e))

    try:
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, 'eve.ckpt')
            save_r = eve_x.save(path)
            saved_path = save_r.get('path', path) if isinstance(save_r, dict) else path
            ok = os.path.exists(saved_path) or os.path.exists(path + '.gz')
            check("51 영속화 호환", ok)
    except Exception as e:
        check("51 영속화 호환", False, str(e))

    try:
        instances = []
        for i in range(3):
            e = EVE_v39(seed_common_sense_on_init=True, use_qwen=False)
            e.enter_room()
            e.say(f"메시지 {i}")
            instances.append(e)
        check("52 동시 인스턴스 3개", all(isinstance(e.em.episodes, dict) for e in instances))
    except Exception as e:
        check("52 동시 인스턴스 3개", False, str(e))

    try:
        eve_x.hs.hormones['oxytocin'].level = 100.0
        result_b = eve_x.say("안녕")
        intent_b = eve_x._build_response_intent("안녕", result_b)
        check("53 호르몬 비정상 clamp",
              intent_b['tone'] in ['warm', 'happy', 'irritated', 'sleepy', 'calm', 'neutral'])
    except Exception as e:
        check("53 호르몬 비정상 clamp", False, str(e))

    try:
        b_bad = BrocaQwen(server_url='not-a-url', timeout=2)
        check("54 잘못된 URL", b_bad.is_alive() == False)
    except Exception as e:
        check("54 잘못된 URL", False, str(e))

    try:
        b_to = BrocaQwen(server_url='http://127.0.0.1:99999', timeout=0.001)
        response_to = b_to.realize({'user_message': 'x'})
        check("55 timeout 0.001", response_to == '')
    except Exception as e:
        check("55 timeout 0.001", False, str(e))

    # ==========================================
    # 결과
    # ==========================================
    print("\n" + "=" * 70)
    print(f"결과: {pass_count}/{pass_count + fail_count} PASS")
    if failed_tests:
        print(f"실패: {failed_tests}")
    print("=" * 70)

    return fail_count == 0


if __name__ == '__main__':
    sys.exit(0 if main() else 1)
