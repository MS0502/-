"""
EVE v38 — AIRI 어댑터 검증
=========================

websockets 라이브러리 없어도 어댑터 자체는 검증 가능.
실제 서버 실행은 Termux에서 (pip install websockets 후).

검증:
1. 호르몬 → 표정 매핑
2. 호르몬 → 색상 매핑
3. 메시지 빌드 (state, speech, proactive)
4. 사용자 메시지 처리 (say 호출)
5. 사용자 액션 처리 (tick, 환경 전환)
"""
import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36
from airi_adapter import AIRIAdapter, compute_expression, compute_eve_color


def passed(name, ok, detail=""):
    mark = "✅" if ok else "❌"
    print(f"  {mark} {name}" + (f"  | {detail}" if detail else ""))
    return ok


def section(t):
    print(f"\n--- {t} ---")


print("=" * 70)
print("  EVE v38 — AIRI 어댑터 검증 (Termux 친화)")
print("=" * 70)
results = []


# ============================================================
# [1] 표정 매핑 — 호르몬 시나리오별
# ============================================================
section("[1] 호르몬 → 표정 매핑")

scenarios = [
    ('happy', {'dopamine': 0.8, 'oxytocin': 0.7, 'cortisol': 0.2,
               'melatonin': 0.1, 'serotonin': 0.6, 'endorphin': 0.5}),
    ('loving', {'oxytocin': 0.9, 'dopamine': 0.5, 'cortisol': 0.2,
                'melatonin': 0.1, 'endorphin': 0.6}),
    ('stressed', {'cortisol': 0.9, 'norepinephrine': 0.7, 'oxytocin': 0.2,
                  'dopamine': 0.2, 'serotonin': 0.2}),
    ('sleepy', {'melatonin': 0.85, 'adenosine': 0.8, 'cortisol': 0.2,
                'dopamine': 0.2}),
    ('calm', {'serotonin': 0.7, 'gaba': 0.6, 'cortisol': 0.15,
              'oxytocin': 0.4, 'dopamine': 0.4}),
    ('alert', {'norepinephrine': 0.75, 'histamine': 0.6, 'cortisol': 0.4,
               'dopamine': 0.5, 'melatonin': 0.1}),
]

for expected, hormones in scenarios:
    expr_info = compute_expression(hormones)
    actual = expr_info['expression']
    print(f"  {expected:10s}: {actual:10s} (intensity={expr_info['intensity']:.2f})")
    results.append(passed(f"{expected} 시나리오 → '{expected}'",
                         actual == expected,
                         f"got={actual}"))


# ============================================================
# [2] 색상 매핑
# ============================================================
section("[2] 호르몬 → 색상")
# 도파민 ↑ → 노랑계열
yellow_color = compute_eve_color({'dopamine': 0.9})
results.append(passed("DA↑ → 노랑계열",
                     yellow_color['r'] > 200 and yellow_color['g'] > 150,
                     f"{yellow_color}"))

# 코르티솔 ↑ → 파랑계열
blue_color = compute_eve_color({'cortisol': 0.9})
results.append(passed("Cort↑ → 파랑계열",
                     blue_color['b'] > 150,
                     f"{blue_color}"))


# ============================================================
# [3] state 메시지 빌드
# ============================================================
section("[3] state 메시지 빌드")
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve.enter_room()
adapter = AIRIAdapter(eve)

state = adapter.build_state_message()
print(f"  type={state['type']}, expression={state['expression']}, mood={state['mood']}")
print(f"  location={state['location']}, period={state['period']}")
print(f"  hormones 키 수: {len(state['hormones'])}")

required = ['type', 'protocol', 'timestamp', 'expression', 'color',
           'feeling', 'location', 'mood', 'hormones', 'expression_scores']
for k in required:
    results.append(passed(f"키 '{k}' 존재", k in state))


# ============================================================
# [4] speech 메시지
# ============================================================
section("[4] speech 메시지")
speech = adapter.build_speech_message("안녕!", is_response=True,
                                     feeling="포근함", pattern="greeting")
print(f"  speech: {speech}")
results.append(passed("speech 메시지 정상",
                     speech['type'] == 'speech'
                     and speech['text'] == '안녕!'
                     and speech['is_response'] == True))


# ============================================================
# [5] proactive 메시지
# ============================================================
section("[5] proactive 메시지")
prox = adapter.build_proactive_message("민석아, 뭐해?", reason="warmth")
results.append(passed("proactive 메시지 정상",
                     prox['type'] == 'proactive'
                     and prox['text'] == '민석아, 뭐해?'))


# ============================================================
# [6] 사용자 메시지 처리
# ============================================================
section("[6] 사용자 메시지 처리 (handle_user_message)")
result = adapter.handle_user_message("기뻐")
print(f"  결과: {result}")
results.append(passed("user_message 처리 성공",
                     result['success'] and bool(result['response']),
                     result.get('response', '')))


# ============================================================
# [7] 사용자 액션 — tick
# ============================================================
section("[7] 사용자 액션 — tick")
result = adapter.handle_user_action('tick', {'dt': 0.5})
print(f"  tick 결과: {result}")
results.append(passed("tick 액션 성공", result['success']))


# ============================================================
# [8] 사용자 액션 — 환경 전환
# ============================================================
section("[8] 환경 전환")
result_room = adapter.handle_user_action('enter_room')
print(f"  내방: {result_room}")
results.append(passed("내방 진입", result_room['success']))

result_living = adapter.handle_user_action('enter_environment',
                                          {'env_name': '거실'})
print(f"  거실: {result_living}")
results.append(passed("거실 진입", result_living['success']))

result_kitchen = adapter.handle_user_action('enter_environment',
                                           {'env_name': '주방'})
print(f"  주방: {result_kitchen}")
results.append(passed("주방 진입", result_kitchen['success']))


# ============================================================
# [9] 사용자 액션 — save/load
# ============================================================
section("[9] save/load 액션")
import tempfile, os
with tempfile.NamedTemporaryFile(suffix='.ckpt', delete=False) as f:
    p = f.name
result_save = adapter.handle_user_action('save', {'path': p})
print(f"  save: {result_save}")
saved_path = result_save.get('path', p)
results.append(passed("save 액션 성공", result_save['success']))
results.append(passed("save 파일 존재",
                     os.path.exists(saved_path)))

# 새 EVE에 load
eve2 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
adapter2 = AIRIAdapter(eve2)
result_load = adapter2.handle_user_action('load', {'path': saved_path})
print(f"  load: {result_load}")
results.append(passed("load 액션 성공", result_load['success']))
results.append(passed("load 후 visit_count 영속",
                     eve2.user_presence.visit_count == eve.user_presence.visit_count))

os.unlink(saved_path)


# ============================================================
# [10] 통합 시연 — say + state + 환경 전환
# ============================================================
section("[10] 통합 — 한 사이클")
eve3 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
adapter3 = AIRIAdapter(eve3)

# 자기 방
adapter3.handle_user_action('enter_room')
state1 = adapter3.build_state_message()
print(f"\n  [자기 방]")
print(f"  expression={state1['expression']}, color=RGB{state1['color']}")
print(f"  feeling='{state1['feeling']}'")

# 사용자 메시지
adapter3.handle_user_message("기뻐 오늘 좋은 일 있었어")
state2 = adapter3.build_state_message()
print(f"\n  [기쁨 메시지 후]")
print(f"  expression={state2['expression']}, mood={state2['mood']}")

# 거실 외출
adapter3.handle_user_action('enter_environment', {'env_name': '거실'})
state3 = adapter3.build_state_message()
print(f"\n  [거실 외출]")
print(f"  location={state3['location']}, is_sim={state3['is_in_simulation']}")

results.append(passed("통합 시연 — 모든 상태 변화 정상",
                     state3['location'] == '거실'
                     and state3['is_in_simulation'] == True))


# ============================================================
# 요약
# ============================================================
print()
print("=" * 70)
total = len(results)
pc = sum(1 for r in results if r)
print(f"  검증: {pc} / {total}")
print("=" * 70)

if pc == total:
    print("\n🎉 v38 AIRI 어댑터 통과!")
    print()
    print("핵심:")
    print("  ✅ 호르몬 26 → 표정 10종 매핑 (happy/loving/stressed/sleepy/...)")
    print("  ✅ 호르몬 → 색상 RGB")
    print("  ✅ state/speech/proactive 메시지 빌드")
    print("  ✅ 사용자 메시지 → EVE.say() 라우팅")
    print("  ✅ 사용자 액션 → tick/환경/save/load 라우팅")
    print()
    print("다음:")
    print("  Termux에서 'pip install websockets'")
    print("  python3 v36_modules/airi_server.py")
    print("  → ws://localhost:8765 또는 ws://<폰IP>:8765")
else:
    print(f"\n⚠ {total - pc}개 실패")
    sys.exit(1)
