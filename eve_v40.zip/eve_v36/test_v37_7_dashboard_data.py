"""
v37.7 — Dashboard 데이터 레이어 검증
"""
import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36
from dashboard_data import (get_eve_state, get_eve_visualization_data,
                            HormoneTracker, hormone_color, blend_colors)


def passed(name, ok, detail=""):
    mark = "✅" if ok else "❌"
    print(f"  {mark} {name}" + (f"  | {detail}" if detail else ""))
    return ok


print("=" * 70)
print("  v37.7 Dashboard 데이터 레이어 검증")
print("=" * 70)
results = []


# [1] 기본 추출
print("\n[1] 빈 EVE 상태 추출")
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
state = get_eve_state(eve)

required = ['time', 'feeling', 'mood', 'hormones', 'eve_color',
           'space', 'mind', 'thoughts', 'recent_actions',
           'recent_dialogue', 'protected']
for k in required:
    results.append(passed(f"키 '{k}' 존재", k in state))

results.append(passed("호르몬 26개", len(state['hormones']) == 26))
results.append(passed("eve_color 3채널", len(state['eve_color']) == 3))


# [2] 자기 방 상태
print("\n[2] 자기 방 진입 상태")
eve.enter_room()
state = get_eve_state(eve)

results.append(passed("env in_env=True", state['space']['in_env']))
results.append(passed("env_name=내방", state['space']['env_name'] == '내방'))
results.append(passed("is_simulation=False", state['space']['is_simulation'] == False))
results.append(passed("객체 6개", len(state['space']['objects']) == 6))
results.append(passed("NPC 0개", len(state['space']['npcs']) == 0))


# [3] 사회 환경
print("\n[3] 사회 환경 (시뮬)")
eve.exit_environment()
from social_env import make_social_living_room
eve.enter_environment(make_social_living_room())
state = get_eve_state(eve)

results.append(passed("is_simulation=True", state['space']['is_simulation'] == True))
results.append(passed("NPC 3명", len(state['space']['npcs']) == 3))
results.append(passed("진수 mood='슬픔'",
                     any(n['name']=='진수' and n['mood']=='슬픔'
                         for n in state['space']['npcs'])))


# [4] 호르몬 색상 + 블렌드
print("\n[4] 색상 매핑")
da_color = hormone_color('dopamine')
ot_color = hormone_color('oxytocin')
results.append(passed("도파민 색 = 노랑계열",
                     da_color[0] > 200 and da_color[1] > 150,
                     f"{da_color}"))
results.append(passed("옥시토신 색 = 핑크계열",
                     ot_color[0] > 200 and ot_color[2] > 100,
                     f"{ot_color}"))

# 블렌드
blended = blend_colors([(da_color, 0.5), (ot_color, 0.5)])
results.append(passed("블렌드 RGB 정상", all(0 <= c <= 255 for c in blended),
                     f"DA+OT 블렌드={blended}"))


# [5] 시각화 데이터
print("\n[5] 시각화 데이터 (별자리)")
eve.exit_environment()
eve.enter_room()
# 일부 카테고리 활성
eve.sa.activate('침대', 0.6)
eve.sa.activate('편안', 0.5)
eve.sa.activate('일기장', 0.4)
viz = get_eve_visualization_data(eve)

results.append(passed("center 존재", 'center' in viz))
results.append(passed("center color 3채널",
                     len(viz['center']['color']) == 3))
results.append(passed("nodes 리스트",
                     isinstance(viz['nodes'], list) and len(viz['nodes']) > 0,
                     f"nodes={len(viz['nodes'])}"))
results.append(passed("nodes 좌표/색/크기 다 있음",
                     all('x' in n and 'y' in n and 'color' in n and 'size' in n
                         for n in viz['nodes'])))


# [6] 시간/일주기
print("\n[6] 시간 필드")
eve.hs.sim_hour = 14.5
state = get_eve_state(eve)
results.append(passed("sim_hour 추출", state['time']['sim_hour'] == 14.5))
results.append(passed("sim_hour_str 포맷",
                     state['time']['sim_hour_str'] == '14:30',
                     state['time']['sim_hour_str']))
results.append(passed("시간대 인식",
                     state['time']['period'] == '오후',
                     state['time']['period']))


# [7] HormoneTracker
print("\n[7] 호르몬 시계열 추적")
tracker = HormoneTracker(max_history=10)

# 5번 스냅샷 (호르몬 변화)
for i in range(5):
    eve.hs.hormones['dopamine'].level = 0.3 + i * 0.1
    eve.tick(dt=0.5)
    tracker.snapshot(eve)

ts, vals = tracker.series('dopamine')
results.append(passed("스냅샷 5개", len(tracker.history) == 5))
results.append(passed("도파민 시계열 단조",
                     vals[0] < vals[-1],
                     f"{vals}"))


# [8] 전체 시연 — 24시간 시뮬 + 트래킹
print("\n[8] 24시간 시뮬 동안 데이터 트래킹")
eve2 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve2.hs.sim_hour = 6.0
eve2.enter_room()
tracker2 = HormoneTracker(max_history=50)

actions = eve2.live_in_room(hours=24, sim_hour_per_step=2.0, verbose=False)
for _ in range(12):  # 12 스냅샷
    tracker2.snapshot(eve2)

state = get_eve_state(eve2)
viz = get_eve_visualization_data(eve2)

print(f"\n  최종 시각: {state['time']['sim_hour_str']} ({state['time']['period']})")
print(f"  feeling: {state['feeling']}")
print(f"  EVE 색상 (RGB): {state['eve_color']}")
print(f"  focus: {state['mind']['focus']}")
print(f"  활성 top 5: {[n['name'] for n in state['mind']['active_categories'][:5]]}")
print(f"  최근 행동: {[a['action'] for a in state['recent_actions'][-5:]]}")
print(f"  주요 호르몬:")
for h_name in ['dopamine', 'oxytocin', 'cortisol', 'melatonin']:
    if h_name in state['hormones']:
        h = state['hormones'][h_name]
        print(f"    {h_name:14s}: {h['level']:.3f}")
print(f"  시각화 nodes: {len(viz['nodes'])}")

results.append(passed("24시간 시뮬 완주",
                     len(actions) >= 10))
results.append(passed("eve_color 변화 (호르몬 따라)",
                     state['eve_color'] != (150, 150, 150)))


# 요약
print()
print("=" * 70)
total = len(results)
pc = sum(1 for r in results if r)
print(f"  검증: {pc} / {total}")
print("=" * 70)

if pc == total:
    print("\n🎉 v37.7 데이터 레이어 통과!")
    print()
    print("  ✅ EVE 상태 → dict 변환 작동")
    print("  ✅ 호르몬 색상 매핑")
    print("  ✅ 추상 시각화 좌표 생성")
    print("  ✅ 24시간 시뮬 트래킹")
    print()
    print("✨ Streamlit/Gradio 어디서든 활용 가능 ✨")
else:
    print(f"\n⚠ {total - pc}개 실패")
    sys.exit(1)
