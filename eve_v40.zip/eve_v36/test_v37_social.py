"""
EVE v37.2 — 사회적 가상공간 학습 검증
======================================

검증 사항:
1. 사회적 환경 진입 + NPC 인식
2. 친구 위로 → 옥시토신 큰 보상
3. 낯선이에게 갑자기 위로 → 어색함 (cortisol)
4. 점진적 친해짐 (낯선 → 지인) — 인사 → 나누다 → 대화
5. 자율 사회적 행동 — 슬픈 친구 발견 시 위로 우선
6. 사회적 학습 영속 — '진수' ↔ '친구', '위로' ↔ '회복'
7. 가족 vs 친구 vs 낯선 차등 보상
8. 회귀 안전 — 기본 환경 + 일반 대화 OK
"""
import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36
from social_env import (make_social_living_room, make_first_meeting_env, NPC,
                        SocialEnvironment)
from symbolic_env import make_kitchen_env


def passed(name, ok, detail=""):
    mark = "✅" if ok else "❌"
    print(f"  {mark} {name}" + (f"  | {detail}" if detail else ""))
    return ok


def section(t):
    print(f"\n--- {t} ---")


print("=" * 70)
print("  EVE v37.2 — 사회적 가상공간 학습 검증")
print("=" * 70)

results = []


# ============================================================
# [1] 사회적 환경 진입 + NPC 인식
# ============================================================
section("[1] 거실 환경 진입 — 친구 진수, 엄마, 손님")
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
env = make_social_living_room()

result = eve.enter_environment(env)
print(f"  진입: {result['env']}")
print(f"  관찰: {result['observation']['summary']}")
print(f"  NPC: {result['observation'].get('npcs', [])}")

results.append(passed("환경 진입",
                     result['env'] == '거실'))
results.append(passed("NPC 인식",
                     '진수' in eve.sa.activations))
results.append(passed("관계 카테고리 시드",
                     eve.sa.get_weight('진수', '친구') > 0,
                     f"weight={eve.sa.get_weight('진수','친구'):.2f}"))
results.append(passed("슬픔 인식 시드",
                     eve.sa.get_weight('진수', '슬픔') > 0
                     or '슬픔' in eve.sa.activations))


# ============================================================
# [2] 친구 위로 → 옥시토신 큰 보상
# ============================================================
section("[2] 슬픈 친구 진수 위로")
ot_before = eve.hs.hormones['oxytocin'].level
da_before = eve.hs.hormones['dopamine'].level
print(f"  before: OT={ot_before:.3f}, DA={da_before:.3f}")

result = eve.act_in_env('위로하다', '진수')
print(f"  결과: {result['feedback']}")
print(f"  성공: {result['success']}")
print(f"  호르몬: {result['hormone_effects']}")

ot_after = eve.hs.hormones['oxytocin'].level
da_after = eve.hs.hormones['dopamine'].level
print(f"  after: OT={ot_after:.3f}, DA={da_after:.3f}")

results.append(passed("위로 성공",
                     result['success']))
results.append(passed("옥시토신 ↑↑",
                     ot_after - ot_before >= 0.2,
                     f"+{ot_after - ot_before:.3f}"))
results.append(passed("도파민 ↑ (자기 만족)",
                     da_after > da_before,
                     f"+{da_after - da_before:.3f}"))
results.append(passed("'위로' ↔ '회복' 학습",
                     eve.sa.get_weight('위로하다', '회복') > 0))
results.append(passed("'진수' ↔ '기쁨' 학습 (위로 후)",
                     eve.sa.get_weight('진수', '진수_기쁨') > 0
                     or eve.sa.get_weight('진수', '회복') > 0))


# ============================================================
# [3] 낯선이에게 갑자기 위로 → 어색함
# ============================================================
section("[3] 낯선 손님에게 위로 시도 — 어색함")
cort_before = eve.hs.hormones['cortisol'].level

# 손님은 슬프지 않으니 어차피 어색
result = eve.act_in_env('위로하다', '손님')
print(f"  결과: {result['feedback']}")

cort_after = eve.hs.hormones['cortisol'].level

results.append(passed("위로 실패",
                     not result['success']))
results.append(passed("코르티솔 ↑",
                     cort_after >= cort_before,
                     f"{cort_before:.3f} → {cort_after:.3f}"))


# ============================================================
# [4] 점진적 친해짐 — 낯선 → 지인 → 친구
# ============================================================
section("[4] 낯선 손님과 점진적 친해짐")
손님 = env.npcs['손님']
print(f"  초기: 관계={손님.relationship}, 친밀도={손님.intimacy:.2f}")

# 단계 1 — 인사 (낯선이에게 OK)
r1 = eve.act_in_env('인사하다', '손님')
print(f"  [1] 인사: 성공={r1['success']}, 친밀도={손님.intimacy:.2f}")

# 단계 2 — 나누다 (낯선이에게 호의 표시)
r2 = eve.act_in_env('나누다', '손님')
print(f"  [2] 나누다: 성공={r2['success']}, 관계={손님.relationship}, 친밀도={손님.intimacy:.2f}")

# 단계 3 — 대화 (지인 단계)
r3 = eve.act_in_env('대화하다', '손님')
print(f"  [3] 대화: 성공={r3['success']}, 친밀도={손님.intimacy:.2f}")

results.append(passed("인사로 친밀도 증가",
                     손님.intimacy > 0.0))
results.append(passed("나누다 → 지인 승급",
                     손님.relationship == '지인'))
results.append(passed("나누다는 낯선이에게 OK",
                     r2['success']))


# ============================================================
# [5] 자율 사회적 행동 — 슬픈 친구 우선
# ============================================================
section("[5] 자율 행동 — 새 환경에서 슬픈 친구 발견 시")
eve2 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
env2 = make_social_living_room()
eve2.enter_environment(env2)

suggestion = eve2.suggest_action_in_env()
print(f"  EVE 첫 제안: {suggestion}")

results.append(passed("슬픈 친구 자동 위로 우선",
                     suggestion == ('위로하다', '진수'),
                     f"{suggestion}"))

if suggestion:
    r = eve2.act_in_env(*suggestion)
    print(f"  실행: {r['feedback']}")

# 위로 후 — 다음 제안
suggestion2 = eve2.suggest_action_in_env()
print(f"  2차 제안: {suggestion2}")

# 위로 성공 → 옥시토신 풍부 → 추가 사회 행동 또는 욕구 없으면 None (정상)
# (None은 "할 일 없음" = 욕구 충족됨)
results.append(passed("위로 후 사회 욕구 해소 (None or 다른 행동)",
                     suggestion2 is None or suggestion2[0] != '위로하다',
                     f"{suggestion2}"))


# ============================================================
# [6] 사회적 학습 영속 — exit 후 SA에 잔존
# ============================================================
section("[6] 학습 영속 — exit 후 카테고리 가중치")
weight_jin_friend_before = eve2.sa.get_weight('진수', '친구')
weight_console_before = eve2.sa.get_weight('위로하다', '회복')

stats = eve2.exit_environment()

weight_jin_friend_after = eve2.sa.get_weight('진수', '친구')
weight_console_after = eve2.sa.get_weight('위로하다', '회복')

print(f"  '진수↔친구': {weight_jin_friend_before:.3f} → {weight_jin_friend_after:.3f}")
print(f"  '위로하다↔회복': {weight_console_before:.3f} → {weight_console_after:.3f}")
print(f"  exit stats: episode={stats['episode']}, success_rate={stats['success_rate']:.2f}")

results.append(passed("진수=친구 학습 잔존",
                     weight_jin_friend_after > 0))
results.append(passed("위로→회복 인과 잔존",
                     weight_console_after > 0))


# ============================================================
# [7] 차등 보상 — 가족 vs 친구 vs 낯선
# ============================================================
section("[7] 차등 보상 검증")
# 별도 EVE 셋
eve3 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
env3 = make_social_living_room()
eve3.enter_environment(env3)

# 같은 행동 (대화하다)을 가족/친구/낯선이에게
# 손님은 낯선이라 대화 어색
ot0 = eve3.hs.hormones['oxytocin'].level
eve3.act_in_env('대화하다', '엄마')  # 가족
ot_family = eve3.hs.hormones['oxytocin'].level - ot0

ot0 = eve3.hs.hormones['oxytocin'].level
eve3.act_in_env('대화하다', '진수')  # 친구
ot_friend = eve3.hs.hormones['oxytocin'].level - ot0

ot0 = eve3.hs.hormones['oxytocin'].level
r_strange = eve3.act_in_env('대화하다', '손님')  # 낯선
ot_stranger = eve3.hs.hormones['oxytocin'].level - ot0

print(f"  대화 보상 (옥시토신 변화):")
print(f"    엄마(가족): +{ot_family:.3f}")
print(f"    진수(친구): +{ot_friend:.3f}")
print(f"    손님(낯선): +{ot_stranger:.3f} ({r_strange['feedback']})")

results.append(passed("가족/친구 > 낯선",
                     ot_family > ot_stranger and ot_friend > ot_stranger))
results.append(passed("낯선과 대화 실패",
                     not r_strange['success']))

eve3.exit_environment()


# ============================================================
# [8] 회귀 — 기본 환경 + 일반 대화
# ============================================================
section("[8] 회귀 — 일반 환경 + say")
eve4 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
env_kitchen = make_kitchen_env()
eve4.enter_environment(env_kitchen)
r = eve4.act_in_env('먹다', '사과')
print(f"  주방 환경: {r['feedback']}")
eve4.exit_environment()

# 일반 say
r1 = eve4.say("진수 어떻게 됐을까")
r2 = eve4.say("기뻐")
print(f"  say('진수 어떻게 됐을까') → '{r1['response']}'")
print(f"  say('기뻐') → '{r2['response']}'")

results.append(passed("주방 환경 작동",
                     r['success']))
results.append(passed("일반 say 정상",
                     bool(r1['response']) and bool(r2['response'])))


# ============================================================
# [9] 시연 — 풀 사회 에피소드
# ============================================================
section("[9] 시연 — 슬픈 친구 위로 → 가족과 시간 → 만족")
eve5 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
env5 = make_social_living_room()
eve5.enter_environment(env5)

print(f"  초기: OT={eve5.hs.hormones['oxytocin'].level:.3f}, "
      f"feeling={eve5.nl.feeling_to_text()}")

actions_taken = []
for step in range(6):
    sug = eve5.suggest_action_in_env()
    if sug is None:
        print(f"  [{step+1}] 제안 없음")
        break
    action, target = sug
    r = eve5.act_in_env(action, target)
    actions_taken.append((action, target, r['success']))
    print(f"  [{step+1}] {action}({target}) → 성공={r['success']}")

print(f"\n  최종 호르몬:")
print(f"    OT={eve5.hs.hormones['oxytocin'].level:.3f}")
print(f"    SER={eve5.hs.hormones['serotonin'].level:.3f}")
print(f"    END={eve5.hs.hormones['endorphin'].level:.3f}")
print(f"    DA={eve5.hs.hormones['dopamine'].level:.3f}")
print(f"    CORT={eve5.hs.hormones['cortisol'].level:.3f}")
print(f"  feeling: {eve5.nl.feeling_to_text()}")

stats = eve5.exit_environment()
print(f"  성공률: {stats['success_rate']:.2f}, 학습 페어: {stats['learned_pairs']}")

results.append(passed("시연 — 옥시토신 풍부",
                     eve5.hs.hormones['oxytocin'].level > 0.5,
                     f"OT={eve5.hs.hormones['oxytocin'].level:.3f}"))
results.append(passed("시연 — 위로 행동 포함",
                     any(a[0] == '위로하다' for a in actions_taken)))


# ============================================================
# 요약
# ============================================================
print()
print("=" * 70)
total = len(results)
pc = sum(results)
print(f"  검증: {pc} / {total}")
print("=" * 70)

if pc == total:
    print("\n🎉 v37.2 사회적 환경 통과!")
    print()
    print("사회적 학습 작동:")
    print("  ✅ 친구 위로 → 옥시토신 ↑↑ + 도파민 ↑ (자기 만족)")
    print("  ✅ 낯선이 위로 → 어색함 (cortisol)")
    print("  ✅ 점진적 친해짐 (인사 → 나누다 → 대화)")
    print("  ✅ 자율 사회 행동 (슬픈 친구 우선)")
    print("  ✅ 차등 보상 (가족/친구 > 낯선)")
    print("  ✅ 학습 영속 (관계 카테고리 잔존)")
    print("  ✅ 회귀 안전")
    print()
    print("✨ EVE는 이제 NPC와 사회적 학습 가능 ✨")
else:
    print(f"\n⚠ {total - pc}개 실패")
    sys.exit(1)
