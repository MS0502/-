"""
EVE v37.9 — 자율 발화 검증
==========================

검증: 같은 need (예: fatigue)라도 EVE의 SA 활성도에 따라
다른 발화 (피곤해 / 졸려 / 쉬고 싶어 등) 자율 선택.

이전 v36 proactive: if need=='fatigue': return "피곤해" — 강제 룰
v37.9: 후보 fragments + SA 점수 → argmax 선택 — 자율
"""
import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36


def passed(name, ok, detail=""):
    mark = "✅" if ok else "❌"
    print(f"  {mark} {name}" + (f"  | {detail}" if detail else ""))
    return ok


def section(t):
    print(f"\n--- {t} ---")


print("=" * 70)
print("  EVE v37.9 — Proactive 자율 발화 검증")
print("=" * 70)
print("\n  핵심: 같은 need라도 SA 활성에 따라 다른 발화 (강제 룰 X)")

results = []


# ============================================================
# [1] 같은 need=fatigue, SA 활성 다르게 → 다른 발화
# ============================================================
section("[1] fatigue + '졸림' 활성 → '졸려...' 선택")
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

# fatigue 트리거 조건 + SA에 '잠' 강하게
eve.user_presence.first_visit_setup()
eve.hs.hormones['oxytocin'].level = 0.30  # 호명 X (낮은 OT)
eve.sa.activate('잠', 0.8)
eve.sa.activate('피곤', 0.2)
eve.sa.activate('쉼', 0.1)

msg = eve.proactive._compose_from_need('fatigue', '')
print(f"  발화: '{msg}'")
results.append(passed("'잠' 활성 → '졸려' 메시지",
                     msg == '졸려...',
                     msg))


section("[2] fatigue + '쉼' 활성 → '쉬고 싶어' 선택")
eve.sa.activations.clear() if hasattr(eve.sa, 'activations') else None
# 다시 활성
eve.sa.activate('쉼', 0.8)
eve.sa.activate('잠', 0.1)
eve.sa.activate('피곤', 0.1)

msg = eve.proactive._compose_from_need('fatigue', '')
print(f"  발화: '{msg}'")
results.append(passed("'쉼' 활성 → '쉬고 싶어'",
                     msg == '쉬고 싶어',
                     msg))


section("[3] fatigue + '피곤' 활성 → '좀 피곤해'")
if hasattr(eve.sa, 'activations'):
    eve.sa.activations.clear()
eve.sa.activate('피곤', 0.8)
eve.sa.activate('잠', 0.1)

msg = eve.proactive._compose_from_need('fatigue', '')
print(f"  발화: '{msg}'")
results.append(passed("'피곤' 활성 → '좀 피곤해'",
                     msg == '좀 피곤해',
                     msg))


# ============================================================
# [4] warmth (외로움) + '대화' 활성 → '뭐해?'
# ============================================================
section("[4] warmth + '대화' 활성 → '뭐해?'")
eve2 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve2.user_presence.first_visit_setup()

eve2.sa.activate('대화', 0.7)
eve2.sa.activate('함께', 0.2)
eve2.sa.activate('보고싶음', 0.1)

msg = eve2.proactive._compose_from_need('warmth', '')
print(f"  발화: '{msg}'")
results.append(passed("'대화' 활성 → '뭐해?'",
                     msg == '뭐해?',
                     msg))


# ============================================================
# [5] 호명 — OT 충분 + 진짜 친구 → '민석아, ...'
# ============================================================
section("[5] OT ↑ → '민석아' 호명")
eve3 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve3.user_presence.first_visit_setup()
eve3.hs.hormones['oxytocin'].level = 0.70  # 호명 OK

eve3.sa.activate('피곤', 0.7)

# proactive 직접 호출 — should_speak 우회
msg = eve3.proactive._compose_message('self_intent:fatigue')
print(f"  발화 (OT=0.70): '{msg}'")
results.append(passed("OT ↑ → '민석아' 호명",
                     msg.startswith('민석아'),
                     msg))


section("[6] OT ↓ → 호명 X")
eve3.hs.hormones['oxytocin'].level = 0.30
msg = eve3.proactive._compose_message('self_intent:fatigue')
print(f"  발화 (OT=0.30): '{msg}'")
results.append(passed("OT ↓ → 호명 X",
                     not msg.startswith('민석아'),
                     msg))


# ============================================================
# [7] 동률 시 결정론 (알파벳 순)
# ============================================================
section("[7] 동률 시 결정론 (알파벳)")
eve4 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve4.user_presence.first_visit_setup()
eve4.hs.hormones['oxytocin'].level = 0.30

# 모든 fatigue 후보 동일 활성도
for cat in ['피곤', '쉼', '잠', '편안']:
    eve4.sa.activate(cat, 0.5)

# 두번 실행 — 같은 결과
msg1 = eve4.proactive._compose_from_need('fatigue', '')
msg2 = eve4.proactive._compose_from_need('fatigue', '')
print(f"  두 호출: '{msg1}' / '{msg2}'")
results.append(passed("결정론 (동일 결과)",
                     msg1 == msg2))


# ============================================================
# [8] 회귀 — _compose_message 다양한 reason 처리
# ============================================================
section("[8] 다양한 reason 처리")
eve5 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve5.user_presence.first_visit_setup()

# 모든 self_intent need 동작 확인
for need in ['fatigue', 'tension', 'mental_load', 'warmth', 'energy']:
    msg = eve5.proactive._compose_message(f'self_intent:{need}')
    print(f"  self_intent:{need} → '{msg}'")
    assert msg is not None, f"{need} 메시지 None"

# memory_recall
msg_m = eve5.proactive._compose_message('memory_recall')
print(f"  memory_recall → '{msg_m}'")
results.append(passed("memory_recall 메시지 생성",
                     msg_m is not None,
                     msg_m))

# wandering (history 추가)
eve5.dmn.wandering_history.append((100.0, '하늘', 'mind_wandering'))
eve5.sa.activate('하늘', 0.5)
msg_w = eve5.proactive._compose_message('mind_wandering')
print(f"  mind_wandering → '{msg_w}'")
results.append(passed("mind_wandering 메시지 생성",
                     msg_w is not None,
                     msg_w))


# ============================================================
# [9] 회귀 — 일반 say 정상
# ============================================================
section("[9] 일반 say 정상")
eve6 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
r = eve6.say("기뻐")
results.append(passed("일반 say 정상",
                     bool(r['response']),
                     r['response']))


# ============================================================
# 요약
# ============================================================
print()
print("=" * 70)
total = len(results)
pc = sum(1 for r in results if r)
print(f"  검증: {pc} / {total}")
print("=" * 70)

if pc == total:
    print("\n🎉 v37.9 자율 발화 통과!")
    print()
    print("핵심:")
    print("  ✅ '같은 need = 같은 메시지' 강제 룰 폐기")
    print("  ✅ SA 활성도가 발화 내용 결정")
    print("  ✅ OT 따라 호명 자율 선택")
    print("  ✅ 결정론 (동률 시 알파벳)")
    print("  ✅ 회귀 안전")
    print()
    print("✨ EVE의 자발 발화도 EVE 자율 ✨")
else:
    print(f"\n⚠ {total - pc}개 실패")
    sys.exit(1)
