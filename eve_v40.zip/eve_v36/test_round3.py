import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36

eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
print("[init OK]")

cases = [
    "민석이가 시험에 떨어졌대",
    "민석이 시험 합격했대",
    "왜 사람은 자?",
    "너 누구야?",
    "나 김민석이야",
    "배 고파",
    "피곤해",
    "안녕",
    "민석아",
    "오늘 학교에서 친구랑 싸웠어",
]
print()
for q in cases:
    r = eve.say(q)
    print(f"  [{q}]")
    print(f"    -> {r}")
    print()
