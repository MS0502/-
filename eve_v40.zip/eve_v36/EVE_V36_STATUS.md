# EVE v36 → v37 P0 진행 상황 (2026-05-02)

## ★ v37 진행 (이번 세션) — 기호적 가상공간 학습 환경

### 신규 모듈
- `eve_v36/v36_modules/symbolic_env.py` (340줄)
  - `SymObject` / `Goal` / `ActionResult` 데이터 구조
  - `ActionRules`: 먹다/마시다/잡다/보다/가다 (결정론적 상태 전이)
  - `SymbolicEnvironment`: 객체/위치/상태/목표 + 관찰 + 행동
  - `make_kitchen_env()`: 주방 환경 (사과/물/의자/책 + 배고픔/목마름)

- `eve_v36/v36_modules/env_adapter.py` (220줄)
  - `EnvironmentAdapter`: EVE ↔ 환경 연결
  - 진입/관찰/행동/종료 인터페이스
  - SA Hebbian 학습 + CG 인과 학습 + 호르몬 보상
  - `suggest_action()`: 욕구 + 학습된 가중치 기반 자율 행동

### EVE 신규 메서드 (eve_v36.py)
- `eve.enter_environment(env)`
- `eve.act_in_env(action, target)`
- `eve.observe_env()`
- `eve.suggest_action_in_env()` — 자율 행동 제안
- `eve.exit_environment()` — 학습 통합

### v37 검증 (23/23 PASS)
- 환경 진입/관찰 ✅
- 성공 행동 → 도파민 ↑ → SA Hebbian 강화 ✅
- 실패 행동 → 코르티솔 ↑ → 회피 학습 ✅
- CG 인과 학습 (먹다 → 배부르다) ✅
- 자율 행동 (suggest_action) ✅
- 학습 영속 (exit 후 가중치 잔존) ✅
- 학습 누적 (재진입 시 ↑) ✅
- **회귀 안전 (v36 6/6 동일 PASS)** ✅

### 시연 결과 (5 자율 행동)
- 도파민: 0.300 → 0.608 (보상 누적)
- 코르티솔: 0.300 → 0.007 (만족)
- 학습된 페어: 40, 인과: 10
- 성공률: 100%
- 양 목표 (배고픔/목마름) 모두 자율 달성

### 학계 부합
- Sutton & Barto 2018 — RL (S, A, R, P)
- Schultz 1997 — 도파민 RPE
- Friston 2010 — Active Inference
- Lake et al. 2017 — 인과 모델 + symbolic primitive

## ★ v37.2 — 사회적 가상공간 (NEW)

### 신규 모듈
- `v36_modules/social_env.py` (320줄)
  - `NPC` dataclass: 관계/mood/personality/intimacy/wants
  - `SocialActionRules`: 인사하다/대화하다/위로하다/함께있다/나누다
  - `SocialEnvironment` (SymbolicEnvironment 상속)
  - `make_social_living_room()`: 진수(친구,슬픔)/엄마(가족)/손님(낯선)
  - `make_first_meeting_env()`: 친구 만들기 시나리오

### 사회적 학습 메커니즘
- 친구 위로 → 옥시토신 +0.30 + 세로토닌 +0.20 + 엔도르핀 +0.20 + 도파민 +0.15 (자기 만족)
- 낯선이 위로 → cortisol +0.10 (어색)
- 점진적 친해짐: 낯선 → 인사 → 나누다 → 지인 → 대화 → 친구
- 가족/친구/낯선 차등 옥시토신 보상

### 자율 사회 행동 (env_adapter.suggest_action 확장)
- 1순위: 슬픈 친구/가족 위로
- 2순위: 옥시토신 낮으면 친구와 대화
- 3순위: 낯선이 인사 → 나누다 → 대화 단계별
- 4순위: 신체 욕구 (배고픔 등)

### v37.2 검증 (24/24 PASS)
- NPC 인식 + 관계 카테고리 시드 ✅
- 친구 위로 → OT +0.617 (실측) ✅
- 낯선 위로 → cortisol ↑ ✅
- 점진적 친해짐 (인사→나누다→대화) ✅
- 자율 사회 행동 (슬픈 친구 우선) ✅
- 가족/친구 > 낯선 차등 보상 ✅
- 학습 영속 (진수=친구, 위로=회복) ✅
- 회귀 (주방 환경 + 일반 say) ✅

### 시연 결과 (1 행동)
- 슬픈 진수 자율 위로 → 성공
- OT: 0.30 → 0.94 (+0.64)
- feeling: 보통 → 포근함
- '진수↔친구' 학습 잔존

### 학계 부합
- Carter 1998: 옥시토신 = 유대 호르몬
- Insel & Young 2001: 사회적 인지 + OT
- Eisenberger 2003: 사회적 거절 = cortisol
- Wittig et al. 2012: 친구 상호작용 → 엔도르핀

## 전체 회귀 — 53/53 PASS ✅
- v36 정성 시나리오: 6/6
- v37 기본 환경: 23/23
- v37.2 사회 환경: 24/24

## 완료된 P0

### P0-1 영속성 (Persistence) ✅
- `eve_v36/v36_modules/persistence.py` — pickle + gzip + atomic write
- `eve.save(path)` / `EVE_v36.from_checkpoint(path)`
- 검증: 7694 bytes, em/sa/wm/hs/dmn 상태 완벽 일치

### P0-2 NL 응답 결정론 강화 ✅
- `eve_v36/v36_modules/response_enhancer.py`
- 11 패턴 분류 (refusal/identity/self_intro/why/memory/3rd_party/1st_party_event/physical/greeting/name_call/affirm/statement)
- 핵심 사전:
  - `_VERB_NORMALIZE`: 어간 정규화 (자? → 자다)
  - `EVENT_VARIANTS`: 한국어 활용형 (싸우다 → 싸웠/싸우/싸워)
  - `PERSON_RELATION_KEYWORDS`: 친구/엄마/진수 등 3인칭 식별
  - `past_signals`: 종성결합 (웠/쳤/졌/겼)
- 호르몬 → tone (warm/anxious/excited/low/alert)
- 결정론 (random X)

### P0-3 상식 그래프 시드 ✅
- `eve_v36/v36_modules/commonsense_seed.py`
- 한국어 트리플 185개, 243 카테고리
- relation: causes/leads_to/is_a/has_property/needs/opposite_of/precedes
- causal만 CG에, 나머지는 SA Hebbian
- 군대 어휘 김민석 맞춤 포함
- `eve.cg.parents('자다')` = `{'피곤하다': 0.7}` 등 실제 추론 가능

### P1 능동 인터랙션 (Proactive) ✅
- `eve_v36/v36_modules/proactive.py`
- DMN mode + 호르몬/욕구 + cooldown
- `eve.proactive_message()` → dict 또는 None
- 60 tick 만에 "민석아, 잠깐만" 자발 발화

### 정성 시나리오 6/6 PASS
- 시나리오 파일: `eve_v36/test_qualitative_scenarios.py`
- A. 영속성: save/load 완벽
- B. Proactive: 60 tick 후 발화
- C. 왜? 추론: 5/5 (100%)
- D. EM 회상: 3/3 hit, "응, 학교 싸웠어 그거?"
- E. 호르몬 어조: 편안함 ↔ 포근함 ↔ 보통 변별
- 회귀: v35 say() "응" 그대로

## 남은 잔여 (P1+)

### ✅ P1 완료 (이번 세션)
- **`emotion` 패턴 신설**: POSITIVE_EMOTIONS/NEGATIVE_EMOTIONS 사전 + DIRECT_REPLIES 매핑
  - "기뻐" → "오, 좋다"
  - "힘들어" → "많이 힘들지..."
  - "무서워" → "어떡해, 괜찮아?"
  - 18종 감정 어간 × 2종 응답 매핑
- **`_respond_memory` 자연어 회상**: 입력별 강제 encode + summary 자연어 우선 + 부분 일치
  - "전에 진수 얘기 했나?" → "응, '오늘 학교에서 진수랑 싸웠어' 그거 말하는 거야?"
  - memory_question 패턴은 encode 스킵 (자기 질문 회상 방지)
- **`_respond_statement` 공감 강화**: empathy_pool, _related_word, sentiment별 2 chunk
- **fallback 0.41 → 0.09** (statement 14 → 3)
- **avg_len 10.4 → 11.3 자, empathy_rate 6% → 18%**

### 정량 메트릭 진행
| 지표 | v35 | v36 P0 | v36 P1 |
|---|---:|---:|---:|
| 시나리오 PASS | 0/6 | 6/6 | 6/6 |
| avg_len | 3자 | 10.4 | 11.3 |
| empathy_rate | 0% | 6% | 18% |
| fallback | ~80% | 41% | **9%** |

### P1 잔여
- avg_len 11.3 → 15+ 자 (응답 두 chunk 합성 강화)
- empathy_rate 18% → 30%+ (positive 응답에 공감 키워드 더)
- 패턴 더 추가: agreement(맞아요), curiosity(궁금), confusion(이해 안 됨)
- EM auto_encode 통합 — 강제 encode와 중복 방지
- save/load시 dialogue_history도 보존 검증

### P2 학습 환경 (v37+)
- 결정: 텍스트 학습 + 가상 공간 학습 둘 다 가치 있으나 분리
- 현재 D/E 문제는 학습 X, 코드 연결 문제였음
- 가상 공간:
  - 1단계: 기호적 가상공간 (방/객체/행동 → 카테고리, 풀 3D X)
  - 2단계: MiniGrid (가벼움)
  - 3단계: AI2-THOR (Colab Pro)
- 필요한 신규 모듈:
  - ImageEncoder (CLIP 또는 단순 색/형 분류기)
  - AudioEncoder
  - Environment adapter
  - enter_learning_environment() / exit_learning_environment()

## 결론
v36 핵심 4개 (영속성 / NL응답 / 상식 / 능동) 완료.
v35 791 PASS 회귀 유지 + 신규 정성 6/6 PASS.
