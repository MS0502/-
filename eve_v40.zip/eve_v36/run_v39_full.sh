#!/bin/bash
# EVE v39 — 풀 가동 (Qwen + EVE 백엔드 + UI 서버)
#
# 사용:
#   chmod +x run_v39_full.sh
#   ./run_v39_full.sh

cd "$(dirname "$0")"

QWEN_MODEL="${QWEN_MODEL:-$HOME/llama.cpp/Qwen3-4B-Instruct-2507-Q4_K_M.gguf}"
QWEN_PORT="${QWEN_PORT:-8080}"
EVE_PORT="${EVE_PORT:-8765}"
UI_PORT="${UI_PORT:-9000}"
LLAMA_BIN="${LLAMA_BIN:-$HOME/llama.cpp/build/bin/llama-server}"

if [ -d venv ] && [ -z "$VIRTUAL_ENV" ]; then
    source venv/bin/activate
fi

if [ ! -f "$QWEN_MODEL" ]; then
    echo "❌ 모델 없음: $QWEN_MODEL"
    exit 1
fi

if [ ! -f "$LLAMA_BIN" ]; then
    echo "❌ llama-server 없음: $LLAMA_BIN"
    exit 1
fi

if command -v termux-wake-lock >/dev/null 2>&1; then
    termux-wake-lock 2>/dev/null
fi

echo "================================================"
echo "  EVE v39 풀 가동"
echo "================================================"
echo "  Qwen 모델: $QWEN_MODEL"
echo "  Qwen 포트: $QWEN_PORT"
echo "  EVE 포트:  $EVE_PORT"
echo "  UI 포트:   $UI_PORT"
echo "================================================"
echo ""

# 1. Qwen 서버
echo "[1/3] Qwen 서버 시작..."
"$LLAMA_BIN" \
    -m "$QWEN_MODEL" \
    -t 4 \
    -c 4096 \
    --host 127.0.0.1 \
    --port "$QWEN_PORT" \
    > qwen_server.log 2>&1 &
QWEN_PID=$!
echo "  → PID: $QWEN_PID"

for i in {1..120}; do
    if curl -s "http://127.0.0.1:$QWEN_PORT/health" > /dev/null 2>&1; then
        echo "  ✅ Qwen 응답 OK ($i초)"
        break
    fi
    sleep 1
    if [ $i -eq 120 ]; then
        echo "  ❌ Qwen 60초 응답 X"
        kill $QWEN_PID 2>/dev/null
        exit 1
    fi
done

# 2. UI 서버 (백그라운드)
echo ""
echo "[2/3] UI 서버 시작..."
cd eve_ui
PORT=$UI_PORT HOST=0.0.0.0 python3 eve_ui_server.py > ../ui_server.log 2>&1 &
UI_PID=$!
cd ..
echo "  → PID: $UI_PID"
echo "  → http://localhost:$UI_PORT/eve_ui.html"

sleep 1

# 3. EVE 백엔드 (WebSocket, 포그라운드)
echo ""
echo "[3/3] EVE 백엔드 시작..."
echo "  → ws://localhost:$EVE_PORT"
echo ""
echo "================================================"
echo "  모든 서비스 실행 중. Ctrl+C로 종료."
echo "  ★ 폰 브라우저에서 http://localhost:$UI_PORT/eve_ui.html"
echo "  ★ 메뉴 → 홈 화면에 추가 → 앱처럼 사용"
echo "================================================"

trap "echo ''; echo '종료...'; kill $QWEN_PID $UI_PID 2>/dev/null; exit 0" INT TERM

EVE_QWEN_URL="http://127.0.0.1:$QWEN_PORT" \
EVE_USE_QWEN=true \
python3 v36_modules/airi_server.py \
    --port "$EVE_PORT" \
    --autosave "$HOME/eve_state.ckpt"

kill $QWEN_PID $UI_PID 2>/dev/null
echo "EVE v39 종료"
