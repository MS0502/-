"""
EVE v37.13 — IntegratedSelf + Goal 검증
========================================

검증:
1. IntegratedSelf snapshot — 모든 모듈 통합 view
2. ThoughtStream — DMN+EM+MC 시간순 통합
3. Goal alignment 점수 → decide_action 반영
4. 응답에 goal 인식 (current_goal → location_query)
5. 분산 자아 원칙 — Self는 read-only, 모듈 수정 X
6. 영속화 안 깨짐
7. 회귀 안전
"""
import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36


def passed(name, ok, detail=""):
    mark = "✅" if ok else "❌"
    print(f"  {mark} {name}" + (f"  | {detail}" if detail else ""))
    return ok


def section(t):
    print(f"\n--- {t} ---")


print("=" * 70)
print("  EVE v37.13 — IntegratedSelf + ThoughtStream + Goal")
print("=" * 70)

results = []


# ============================================================
# [1] IntegratedSelf 부착됨
# ============================================================
section("[1] IntegratedSelf 자동 부착")
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

results.append(passed("self_view 속성 존재",
                     hasattr(eve, 'self_view') and eve.self_view is not None))


# ============================================================
# [2] snapshot — 모든 모듈 통합 view
# ============================================================
section("[2] snapshot 모든 필드 채워짐")
eve.enter_room()
eve.say("안녕")
snap = eve.self_view.snapshot()
d = snap.to_dict()

required_keys = ['time', 'sim_hour', 'feeling', 'mood', 'focus',
                'active_categories', 'location', 'is_in_simulation',
                'protected_categories', 'user_intimacy', 'user_visit_count',
                'recent_thoughts', 'recent_actions', 'current_goals',
                'tick_count']
for k in required_keys:
    results.append(passed(f"키 '{k}'", k in d))

results.append(passed("location='내방'", snap.location == '내방'))
results.append(passed("is_in_simulation=False",
                     snap.is_in_simulation == False))
results.append(passed("user_visit_count > 0",
                     snap.user_visit_count > 0))
results.append(passed("user_intimacy > 0",
                     snap.user_intimacy > 0,
                     f"{snap.user_intimacy:.3f}"))


# ============================================================
# [3] summary — 자연어 한 줄
# ============================================================
section("[3] summary 한 줄 표현")
summ = snap.summary()
print(f"  summary: '{summ}'")
results.append(passed("summary 비어있지 않음",
                     bool(summ),
                     summ))
results.append(passed("'내방' 포함",
                     '내방' in summ))


# ============================================================
# [4] thought_stream — 시간순 통합
# ============================================================
section("[4] thought_stream — DMN/EM/MC 통합")
# 약간 tick 진행 → DMN wandering 발생
for _ in range(20):
    eve.tick()
eve.self_view.snapshot()  # 다시

stream = eve.self_view.thought_stream(n=5)
print(f"  thought_stream 길이: {len(stream)}")
print(f"  최근 3개:")
for t in stream[:3]:
    print(f"    [{t.get('time', 0):.1f}s] {t.get('source')} / {t.get('mode')} / {t.get('content')}")

results.append(passed("thought_stream 작동",
                     isinstance(stream, list)))


# ============================================================
# [5] Goal alignment 점수 작동
# ============================================================
section("[5] Goal alignment 점수")

# Goal 인위 추가
if hasattr(eve, 'gm') and eve.gm is not None:
    try:
        # 실제 GM API에 맞게 — 간단히 propose 시도
        eve.gm.propose_goal_from_need()
        active_goals = eve.gm.active_goals()
        print(f"  active goals: {len(active_goals)}")
        for g in active_goals[:3]:
            print(f"    - {getattr(g, 'category', '?')} (priority={getattr(g, 'priority', 0):.2f})")
    except Exception as e:
        print(f"  goal propose 실패: {e}")

# self_view goal_alignment 호출
score1 = eve.self_view.goal_alignment_score('대화하다', '민석')
score2 = eve.self_view.goal_alignment_score('먹다', '사과')
print(f"  '대화하다' alignment: {score1:.3f}")
print(f"  '먹다' alignment: {score2:.3f}")

results.append(passed("goal_alignment_score 작동 (float)",
                     isinstance(score1, float) and isinstance(score2, float)))


# ============================================================
# [6] decide_action에 goal 점수 반영
# ============================================================
section("[6] decide_action — goal alignment 활용")
eve2 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve2.enter_room()
eve2.hs.sim_hour = 14.0

# 인위적으로 goal 활성 (예: '편안')
if hasattr(eve2, 'gm'):
    # propose 자동 (피곤 상태)
    eve2.hs.hormones['adenosine'].level = 0.7
    eve2.gm.propose_goal_from_need()
    eve2.gm.tick(dt=0.5)

# 결정
decision = eve2._env_adapter.decide_action(verbose=True)
print(f"\n  결정: {decision}")

# breakdown 확인 — goal_alignment 키가 있는지
if eve2._env_adapter._decider and eve2._env_adapter._decider.last_decision:
    bd = eve2._env_adapter._decider.last_decision.score_breakdown
    print(f"  breakdown: { {k: round(v, 3) for k, v in bd.items()} }")

results.append(passed("결정 내려짐",
                     decision is not None,
                     f"{decision}"))


# ============================================================
# [7] 영속화 호환성
# ============================================================
section("[7] save/load — self_view 영속")
import tempfile
with tempfile.NamedTemporaryFile(suffix='.ckpt', delete=False) as f:
    p = f.name
save_info = eve.save(p)
p = save_info['path']

eve3 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve3.load(p)

results.append(passed("load 성공 — self_view 자동 재생성",
                     hasattr(eve3, 'self_view') and eve3.self_view is not None))

# load 후 snapshot 작동
snap2 = eve3.self_view.snapshot()
results.append(passed("load 후 snapshot 작동",
                     snap2.user_visit_count > 0))

import os
os.unlink(p)


# ============================================================
# [8] 분산 자아 원칙 — read-only 검증
# ============================================================
section("[8] IntegratedSelf는 read-only (모듈 수정 X)")
eve4 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

# 호르몬 + SA 활성 기록
da_before = eve4.hs.hormones['dopamine'].level
sa_count_before = len(eve4.sa.activations)
wm_count_before = len(eve4.wm.slots)

# snapshot 100번 호출 — 어떤 영향도 없어야
for _ in range(100):
    eve4.self_view.snapshot()

da_after = eve4.hs.hormones['dopamine'].level
sa_count_after = len(eve4.sa.activations)
wm_count_after = len(eve4.wm.slots)

results.append(passed("호르몬 변경 없음",
                     abs(da_after - da_before) < 0.001,
                     f"{da_before:.3f} → {da_after:.3f}"))
results.append(passed("SA 활성 변경 없음",
                     sa_count_after == sa_count_before))
results.append(passed("WM 변경 없음",
                     wm_count_after == wm_count_before))


# ============================================================
# [9] 응답에 goal 인식 — current_goal → location_query
# ============================================================
section("[9] '뭐해?' 응답에 goal 반영")
eve5 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve5.enter_room()
eve5.hs.sim_hour = 14.0

# 행동 없을 때 — goal이 있다면 응답에 반영
if hasattr(eve5, 'gm'):
    eve5.hs.hormones['adenosine'].level = 0.7  # 피곤 → 편안 goal
    eve5.gm.propose_goal_from_need()

eve5.hs.hormones['oxytocin'].level = 0.7  # warm

r = eve5.say("뭐해?")
print(f"  EVE: '{r['response']}'")
results.append(passed("응답 생성됨",
                     bool(r['response']),
                     r['response']))


# ============================================================
# [10] 회귀 — 일반 say 정상
# ============================================================
section("[10] 회귀 — 일반 say")
eve6 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
test_msgs = ["기뻐", "안녕", "어디야?", "왜 그래?"]
for msg in test_msgs:
    r = eve6.say(msg)
    print(f"  '{msg}' → '{r['response']}'")
    assert r['response'], f"{msg} 응답 없음"
results.append(passed("일반 say 정상", True))


# ============================================================
# 요약
# ============================================================
print()
print("=" * 70)
total = len(results)
pc = sum(1 for r in results if r)
print(f"  검증: {pc} / {total}")
print("=" * 70)

if pc == total:
    print("\n🎉 v37.13 IntegratedSelf + Goal 통과!")
    print()
    print("핵심:")
    print("  ✅ IntegratedSelf — 분산 자아 통합 view (read-only)")
    print("  ✅ snapshot 17 필드 (체+정신+정체성+공간+시간+의도)")
    print("  ✅ thought_stream — DMN+EM+MC 시간순 통합")
    print("  ✅ goal_alignment_score → decide_action 반영")
    print("  ✅ 응답에 goal 인식 가능")
    print("  ✅ 영속화 호환")
    print("  ✅ Self는 모듈 수정 X (분산 emergent 원칙)")
    print()
    print("✨ EVE 분산 자아 — 통제 타워가 아닌 통합 view ✨")
else:
    print(f"\n⚠ {total - pc}개 실패")
    sys.exit(1)
