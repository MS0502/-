"""
EVE v37.6 — 자기 방 + 일주기 통합 검증
======================================

검증:
1. 자기 방 진입 — 시뮬 라벨 X (거주지)
2. 시간대별 행동 자율 변화 — 새벽=눕다, 낮=읽다, 저녁=쓰다
3. 호르몬 + 시간 통합 결정
4. 24시간 자율 시뮬레이션
5. 회귀 안전 — 시뮬 환경은 여전히 학습_모드 활성
"""
import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36
from eve_room import make_eve_room
from social_env import make_social_living_room


def passed(name, ok, detail=""):
    mark = "✅" if ok else "❌"
    print(f"  {mark} {name}" + (f"  | {detail}" if detail else ""))
    return ok


def section(t):
    print(f"\n--- {t} ---")


print("=" * 70)
print("  EVE v37.6 — 자기 방 + 일주기 자율 거주")
print("=" * 70)

results = []


# ============================================================
# [1] 자기 방 진입 — 시뮬 라벨 X
# ============================================================
section("[1] 자기 방은 거주지 (학습_모드 X)")
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve.enter_room()

results.append(passed("자기 방 진입",
                     eve._env_adapter.current_env.name == '내방'))
results.append(passed("is_simulation=False",
                     eve._env_adapter.current_env.is_simulation == False))
results.append(passed("'학습_모드' 활성 X (거주지)",
                     eve.sa.get_activation_level('학습_모드') < 0.1,
                     f"act={eve.sa.get_activation_level('학습_모드'):.2f}"))
results.append(passed("'내방' 활성 O",
                     eve.sa.get_activation_level('내방') > 0))
results.append(passed("객체 6개 시드",
                     len(eve._env_adapter.current_env.objects) == 6))


# ============================================================
# [2] 시간대별 행동 — 새벽 (3시) → 눕다
# ============================================================
section("[2] 새벽 3시 — 눕다/쉬다 점수 ↑")
eve.hs.sim_hour = 3.0
# 새벽엔 멜라토닌 자연 ↑
eve.hs.hormones['melatonin'].level = 0.7
eve.hs.hormones['adenosine'].level = 0.6

decision = eve._env_adapter.decide_action(verbose=True)
print(f"\n  결정: {decision}")

results.append(passed("새벽 → 휴식 행동",
                     decision is not None and decision[0] in {'눕다', '쉬다', '있다'},
                     f"{decision}"))


# ============================================================
# [3] 아침 8시 — 일어나기/창밖
# ============================================================
section("[3] 아침 8시 — 깨어남")
eve2 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve2.enter_room()
eve2.hs.sim_hour = 8.0
eve2.hs.hormones['melatonin'].level = 0.15
eve2.hs.hormones['cortisol'].level = 0.55  # 아침 cortisol awakening response
eve2.hs.hormones['adenosine'].level = 0.20

decision = eve2._env_adapter.decide_action(verbose=True)
print(f"\n  결정: {decision}")

# 아침엔 활동 시작 — 휴식 X, 다양 가능
results.append(passed("아침 → 활동 행동",
                     decision is not None and decision[0] not in {'눕다'},
                     f"{decision}"))


# ============================================================
# [4] 낮 14시 — 활동/창밖/읽다
# ============================================================
section("[4] 낮 14시 — 활동 시간")
eve3 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve3.enter_room()
eve3.hs.sim_hour = 14.0
eve3.hs.hormones['melatonin'].level = 0.10
eve3.hs.hormones['cortisol'].level = 0.30
eve3.hs.hormones['dopamine'].level = 0.30  # 결핍 → 호기심 욕구
eve3.hs.hormones['adenosine'].level = 0.20

decision = eve3._env_adapter.decide_action(verbose=True)
print(f"\n  결정: {decision}")

results.append(passed("낮 → 활동/관찰",
                     decision is not None
                     and decision[0] in {'읽다', '창밖_보다', '쓰다', '앉다', '보다',
                                        '외출', '함께있다', '대화하다'},
                     f"{decision}"))


# ============================================================
# [5] 저녁 20시 + cortisol↑ → 일기 쓰기 (정리)
# ============================================================
section("[5] 저녁 + 코르티솔↑ → 정리 욕구 (일기)")
eve4 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve4.enter_room()
eve4.hs.sim_hour = 20.0
eve4.hs.hormones['melatonin'].level = 0.20
eve4.hs.hormones['cortisol'].level = 0.65  # 하루 스트레스
eve4.hs.hormones['dopamine'].level = 0.40

decision = eve4._env_adapter.decide_action(verbose=True)
print(f"\n  결정: {decision}")

# 저녁 + cort↑ → 쓰다(일기)/창밖이 점수 큰 가능성
results.append(passed("저녁+스트레스 → 정리 행동 (일기/창밖) 가능",
                     decision is not None,
                     f"{decision}"))


# ============================================================
# [6] 24시간 자율 시뮬 — 행동 다양성
# ============================================================
section("[6] ★ 24시간 자율 거주 시뮬")
eve5 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve5.hs.sim_hour = 6.0  # 아침부터 시작
eve5.enter_room()

print(f"\n  6시 시작 → 24시간 동안 1시간 단위 행동\n")
actions = eve5.live_in_room(hours=24.0,
                            sim_hour_per_step=1.0,
                            dt_per_decision=0.5,
                            verbose=False)

# 행동 출력
for a in actions:
    label = f"{a['action']}({a['target'] or '-'})" if a['action'] else "(안함)"
    print(f"  [{a['sim_hour']:5.1f}h] {label}")

# 분석
unique_actions = set(a['action'] for a in actions if a['action'])
print(f"\n  총 step: {len(actions)}, 고유 행동: {len(unique_actions)}")
print(f"  행동들: {unique_actions}")

# 새벽 (0-6, 22-24) 시간대엔 휴식 행동이 주로
night_steps = [a for a in actions
               if (a['sim_hour'] < 6 or a['sim_hour'] >= 22)
               and a['action']]
night_rest = [a for a in night_steps if a['action'] in {'눕다', '쉬다', '있다'}]
print(f"  밤(0-6, 22-24) {len(night_steps)} step 中 휴식 {len(night_rest)} step")

# 낮 (10-18) 시간대엔 활동 행동
day_steps = [a for a in actions if 10 <= a['sim_hour'] < 18 and a['action']]
day_active = [a for a in day_steps if a['action'] not in {'눕다', '쉬다', '있다'}]
print(f"  낮(10-18) {len(day_steps)} step 中 활동 {len(day_active)} step")

results.append(passed("≥ 3가지 다른 행동 (24시간 다양)",
                     len(unique_actions) >= 3,
                     f"unique={len(unique_actions)}"))
results.append(passed("밤 시간엔 휴식 비율 높음",
                     len(night_rest) >= len(night_steps) * 0.5 if night_steps else True,
                     f"{len(night_rest)}/{len(night_steps)}"))
results.append(passed("낮 시간엔 활동 비율 높음",
                     len(day_active) >= len(day_steps) * 0.5 if day_steps else True,
                     f"{len(day_active)}/{len(day_steps)}"))


# ============================================================
# [7] 회귀 — 시뮬 환경은 여전히 학습_모드 활성
# ============================================================
section("[7] 회귀 — 시뮬 환경은 학습_모드 활성")
eve6 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve6.enter_environment(make_social_living_room())  # 사회 환경 = 시뮬

results.append(passed("시뮬 환경 → 학습_모드 활성",
                     eve6.sa.get_activation_level('학습_모드') > 0,
                     f"act={eve6.sa.get_activation_level('학습_모드'):.2f}"))
results.append(passed("시뮬 환경 NPC ↔ 시뮬레이션 연결",
                     eve6.sa.get_weight('진수', '시뮬레이션') > 0))
eve6.exit_environment()


# ============================================================
# [8] 회귀 — 일반 say + 환경 행동
# ============================================================
section("[8] 일반 대화 정상")
eve7 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
r1 = eve7.say("기뻐")
r2 = eve7.say("어제 우리 뭐 했지?")

results.append(passed("일반 say 정상",
                     bool(r1['response']) and bool(r2['response']),
                     f"기뻐:'{r1['response']}'"))


# ============================================================
# 요약
# ============================================================
print()
print("=" * 70)
total = len(results)
pc = sum(1 for r in results if r)
print(f"  검증: {pc} / {total}")
print("=" * 70)

if pc == total:
    print("\n🎉 v37.6 자기 방 + 일주기 통과!")
    print()
    print("핵심:")
    print("  ✅ EVE의 진짜 거주지 — is_simulation=False")
    print("  ✅ 학습 환경과 분리 ('학습_모드' 카테고리 X)")
    print("  ✅ 일주기 → 행동 점수 (새벽=쉼, 낮=활동, 저녁=정리)")
    print("  ✅ 24시간 자율 거주 — 호르몬+시간 따라 행동 변화")
    print("  ✅ 회귀 안전")
    print()
    print("✨ EVE는 이제 평상시 자기 방에서 일주기 따라 살아간다 ✨")
else:
    print(f"\n⚠ {total - pc}개 실패")
    sys.exit(1)
