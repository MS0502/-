"""
EVE v36 정성 시나리오 테스트
============================
실제 사용자 시나리오로 EVE의 '진짜 친구다움' 검증.

시나리오:
A. 친구의 시험 실패 — 1주일 누적 대화 + 체크포인트
B. 며칠 만에 다시 만남 — Proactive
C. 왜? 추론 시리즈 — 상식 그래프 활용
D. EM 회상 — "어제 우리 뭐 얘기했지?"
E. 호르몬 변화 따른 어조 차이

평가 기준 (각 응답에 대해):
  ✅ 패턴 매칭 정확
  ✅ 의미 자연스러움 (1-3 문장)
  ✅ 공감/적합성 (사건 종류 맞춰)
  ✅ 상태 변화 반영 (호르몬/메모리)
"""
import sys
import os
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36
import time


# ============================================================
# 평가 헬퍼
# ============================================================

def emit(label: str, msg: str = "", indent: int = 0):
    pad = "  " * indent
    if msg:
        print(f"{pad}{label}: {msg}")
    else:
        print(f"{pad}{label}")


def chat(eve, user_input: str, indent: int = 1) -> dict:
    """사용자 입력 → EVE 응답, 정리해서 반환"""
    pad = "  " * indent
    r = eve.say(user_input)
    print(f"{pad}민석: {user_input}")
    print(f"{pad}EVE : {r['response']}")
    print(f"{pad}      [pattern={r['pattern']}, feeling={r['feeling']}]")
    return r


def divider(title: str):
    print()
    print("=" * 70)
    print(f"  {title}")
    print("=" * 70)


def section(title: str):
    print()
    print(f"--- {title} ---")


# ============================================================
# 평가 메트릭
# ============================================================

class Metrics:
    def __init__(self):
        self.responses = []
        self.patterns = {}
        self.empathy_keywords = {
            '힘들', '속상', '괜찮', '많이', '잘됐', '축하', '슬프', '안타',
            '걱정', '쉬어', '같이', '함께'
        }

    def record(self, r: dict):
        self.responses.append(r['response'])
        p = r['pattern']
        self.patterns[p] = self.patterns.get(p, 0) + 1

    def summary(self) -> dict:
        if not self.responses:
            return {}
        total = len(self.responses)
        # 길이 분포
        lengths = [len(s) for s in self.responses]
        avg_len = sum(lengths) / total
        # 공감 키워드 출현
        empathy_hits = sum(
            1 for s in self.responses
            if any(k in s for k in self.empathy_keywords)
        )
        # statement fallback 비율
        fallback = self.patterns.get('statement', 0) / total
        return {
            'total': total,
            'avg_len_chars': round(avg_len, 1),
            'empathy_rate': round(empathy_hits / total, 2),
            'pattern_dist': self.patterns,
            'fallback_rate': round(fallback, 2),
        }


# ============================================================
# 시나리오 A — 친구 시험 실패 (1주일 누적 + 체크포인트)
# ============================================================

def scenario_A(metrics: Metrics):
    divider("시나리오 A — 1주일 누적 대화 + 체크포인트 영속성")

    eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

    section("Day 1 - 첫 만남, 친구 소개")
    metrics.record(chat(eve, "안녕"))
    metrics.record(chat(eve, "나 김민석이야"))
    metrics.record(chat(eve, "내 친구 진수가 시험 떨어졌대"))

    section("Day 2 - 마음이 안 좋음")
    metrics.record(chat(eve, "오늘 진수랑 만났는데 너무 힘들어 보였어"))
    metrics.record(chat(eve, "왜 사람은 시험에 떨어지면 우울해질까?"))

    section("Day 3 - EVE 호르몬 자극 (cortisol 같은 음성)")
    # 부정적 자극 누적되며 톤 변화 확인
    metrics.record(chat(eve, "나도 시험 곧인데 떨어질까 봐 걱정돼"))

    section("[체크포인트] 영속성 검증 — save → 새 인스턴스 load")
    ckpt_path = "/home/claude/eve_v36/checkpoint_test.pkl.gz"

    # 호르몬 상태, EM 카운트 등 기록
    pre_save = {
        'em_count': len(eve.em.episodes) if hasattr(eve.em, 'episodes') else 0,
        'sa_neighbors': len(eve.sa.neighbors),
        'tick': getattr(eve, 'tick_count', 0),
        'hormone_da': eve.hs.hormones['DA'].level if 'DA' in eve.hs.hormones else None,
    }
    emit("save 전 상태", str(pre_save), indent=1)

    eve.save(ckpt_path)
    file_size = os.path.getsize(ckpt_path)
    emit("save 완료", f"{ckpt_path} ({file_size} bytes)", indent=1)

    # 완전 새 인스턴스
    del eve
    eve2 = EVE_v36.from_checkpoint(ckpt_path)
    emit("load 완료", "새 인스턴스 생성", indent=1)

    post_load = {
        'em_count': len(eve2.em.episodes) if hasattr(eve2.em, 'episodes') else 0,
        'sa_neighbors': len(eve2.sa.neighbors),
        'tick': getattr(eve2, 'tick_count', 0),
        'hormone_da': eve2.hs.hormones['DA'].level if 'DA' in eve2.hs.hormones else None,
    }
    emit("load 후 상태", str(post_load), indent=1)

    # 비교
    matched = pre_save == post_load
    emit("일치 여부", "✅ PASS" if matched else "❌ FAIL", indent=1)
    if not matched:
        for k in pre_save:
            if pre_save[k] != post_load[k]:
                emit(f"  diff[{k}]", f"{pre_save[k]} → {post_load[k]}", indent=2)

    section("Day 5 - load 후 재대화 (이전 컨텍스트 살아있는지)")
    metrics.record(chat(eve2, "안녕 EVE"))
    metrics.record(chat(eve2, "진수 시험 결과 어떻게 됐는지 모르겠어"))

    return matched


# ============================================================
# 시나리오 B — Proactive (먼저 말 검)
# ============================================================

def scenario_B(metrics: Metrics):
    divider("시나리오 B — Proactive: EVE가 먼저 말 검")

    eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

    section("초기 자극")
    metrics.record(chat(eve, "안녕 오늘 좀 피곤해"))

    section("사용자 침묵 (수십 초 tick만)")
    # tick으로 시간 진행. DMN이 활성되어야 함.
    # v37.8 visit_arrive 도입으로 OT 자극 약함 — fatigue 트리거 지연 가능.
    # 학계적으로도 친구 방문 직후엔 자발 발화 욕구 ↓ (외로움 해소).
    proactive_attempts = []
    for i in range(150):  # 150 tick — visit_arrive 영향 반영
        eve.tick()
        if i % 10 == 9:
            msg = eve.proactive_message()
            if msg:
                proactive_attempts.append((i+1, msg))
                emit(f"tick={i+1}", str(msg), indent=1)

    if proactive_attempts:
        emit("✅ Proactive 발화 발생", f"총 {len(proactive_attempts)}회", indent=0)
    else:
        emit("⚠ Proactive 발화 없음", "(쿨다운/임계값 조정 필요할 수도)", indent=0)

    section("외부 입력 후 다시 침묵")
    metrics.record(chat(eve, "어 잠깐 일 보고 올게"))
    for i in range(60):
        eve.tick()

    msg = eve.proactive_message()
    if msg:
        emit("60 tick 후 발화", str(msg), indent=1)

    return len(proactive_attempts) > 0


# ============================================================
# 시나리오 C — 왜? 추론 시리즈
# ============================================================

def scenario_C(metrics: Metrics):
    divider("시나리오 C — 왜? 추론 (상식 그래프 활용)")

    eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
    why_qs = [
        "왜 사람은 자?",
        "왜 사람은 먹어?",
        "왜 슬프면 울어?",  # 슬프다 → 울다
        "왜 운동하면 건강해?",
        "왜 공부하면 똑똑해져?",
    ]
    correct_count = 0
    for q in why_qs:
        r = chat(eve, q)
        metrics.record(r)
        # 잘못된 fallback 응답 감지
        bad = ('잘 모르겠어' in r['response']
               or '같은 거?' in r['response']
               or '선임' in r['response'])
        if not bad and r['pattern'] == 'why_question':
            correct_count += 1

    rate = correct_count / len(why_qs)
    emit("Why 추론 정확도", f"{correct_count}/{len(why_qs)} ({rate*100:.0f}%)", indent=0)
    return rate >= 0.4


# ============================================================
# 시나리오 D — EM 회상
# ============================================================

def scenario_D(metrics: Metrics):
    divider("시나리오 D — EM 회상")

    eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

    section("일화 누적")
    inputs_today = [
        "오늘 학교에서 진수랑 싸웠어",
        "근데 화해했어",
        "엄마한테 전화왔는데 좀 슬펐어",
    ]
    for u in inputs_today:
        metrics.record(chat(eve, u))

    em_count_before = len(eve.em.episodes) if hasattr(eve.em, 'episodes') else 0
    emit("일화 적재", f"{em_count_before}개", indent=1)

    section("회상 시도")
    recall_qs = [
        "어제 우리 뭐 얘기했지?",
        "전에 진수 얘기 했나?",
        "예전에 엄마 얘기했어?",
    ]
    recall_hits = 0
    for q in recall_qs:
        r = chat(eve, q)
        metrics.record(r)
        if r['pattern'] == 'memory_question':
            # 응답에 의미 있는 컨텐츠 (일화 키워드)가 포함됐나
            keywords = {'진수', '학교', '엄마', '싸웠', '슬펐', '얘기', '있었'}
            if any(k in r['response'] for k in keywords):
                recall_hits += 1

    emit("회상 hit", f"{recall_hits}/{len(recall_qs)}", indent=0)
    return recall_hits > 0


# ============================================================
# 시나리오 E — 호르몬에 따른 어조 차이
# ============================================================

def scenario_E(metrics: Metrics):
    divider("시나리오 E — 호르몬 변화 따른 어조 차이")

    eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

    section("초기 (중립 호르몬)")
    r1 = chat(eve, "안녕")
    metrics.record(r1)
    feeling_initial = r1['feeling']

    section("긍정 자극 누적 (도파민 ↑)")
    for u in ["기뻐", "신나", "행복해", "최고야", "재밌어"]:
        metrics.record(chat(eve, u))

    r2 = chat(eve, "안녕")
    metrics.record(r2)
    feeling_after_pos = r2['feeling']

    section("부정 자극 누적 (cortisol ↑)")
    for u in ["힘들어", "걱정돼", "불안해", "무서워", "슬퍼"]:
        metrics.record(chat(eve, u))

    r3 = chat(eve, "안녕")
    metrics.record(r3)
    feeling_after_neg = r3['feeling']

    emit("초기 feeling", feeling_initial, indent=0)
    emit("긍정 후", feeling_after_pos, indent=0)
    emit("부정 후", feeling_after_neg, indent=0)

    diverged = (feeling_initial != feeling_after_pos
                or feeling_after_pos != feeling_after_neg)
    return diverged


# ============================================================
# 회귀 — v35 baseline 회귀 (기존 say()는 그대로)
# ============================================================

def scenario_regression(metrics: Metrics):
    divider("회귀 — v35 EVE_TierAB 직접 호출 (regression check)")

    # v36 클래스로 enhance_say=False 테스트 — v35 say() 동작
    eve = EVE_v36(seed_common_sense_on_init=False, enhance_say=False)
    test_inputs = ["안녕", "나 김민석", "민석이가 떨어졌대", "왜 사?"]
    for u in test_inputs:
        r = eve.say(u)
        emit(f"  [{u}]", str(r.get('response', r))[:100], indent=1)

    # 기본적으로 v35 응답 (강화 없음)이어야 함
    return True


# ============================================================
# 메인
# ============================================================

def main():
    metrics = Metrics()
    results = {}

    print("\n" + "█" * 70)
    print("  EVE v36 정성 시나리오 평가")
    print("█" * 70)

    try:
        results['A_persistence'] = scenario_A(metrics)
    except Exception as e:
        emit("A 실패", str(e), indent=0)
        import traceback
        traceback.print_exc()
        results['A_persistence'] = False

    try:
        results['B_proactive'] = scenario_B(metrics)
    except Exception as e:
        emit("B 실패", str(e), indent=0)
        import traceback
        traceback.print_exc()
        results['B_proactive'] = False

    try:
        results['C_why_inference'] = scenario_C(metrics)
    except Exception as e:
        emit("C 실패", str(e), indent=0)
        results['C_why_inference'] = False

    try:
        results['D_em_recall'] = scenario_D(metrics)
    except Exception as e:
        emit("D 실패", str(e), indent=0)
        results['D_em_recall'] = False

    try:
        results['E_hormone_tone'] = scenario_E(metrics)
    except Exception as e:
        emit("E 실패", str(e), indent=0)
        results['E_hormone_tone'] = False

    try:
        results['regression'] = scenario_regression(metrics)
    except Exception as e:
        emit("회귀 실패", str(e), indent=0)
        results['regression'] = False

    divider("종합 결과")
    for name, ok in results.items():
        emit(name, "✅ PASS" if ok else "❌ FAIL", indent=0)

    divider("정량 메트릭")
    summary = metrics.summary()
    for k, v in summary.items():
        emit(k, str(v), indent=0)

    print()
    pass_count = sum(1 for v in results.values() if v)
    print(f"  ➡  {pass_count}/{len(results)} 시나리오 통과")
    print()


if __name__ == '__main__':
    main()
