#!/bin/bash
# EVE v39 — Qwen 서버 + EVE 백엔드 동시 시작 (Termux)
#
# 사용:
#   chmod +x run_v39.sh
#   ./run_v39.sh
#
# 환경:
#   QWEN_MODEL: 모델 경로 (기본: ~/llama.cpp/Qwen3-4B-Instruct-2507-Q4_K_M.gguf)
#   QWEN_PORT: 서버 포트 (기본: 8080)
#   EVE_PORT: EVE WebSocket 포트 (기본: 8765)

cd "$(dirname "$0")"

QWEN_MODEL="${QWEN_MODEL:-$HOME/llama.cpp/Qwen3-4B-Instruct-2507-Q4_K_M.gguf}"
QWEN_PORT="${QWEN_PORT:-8080}"
EVE_PORT="${EVE_PORT:-8765}"
LLAMA_BIN="${LLAMA_BIN:-$HOME/llama.cpp/build/bin/llama-server}"

# 가상환경 활성
if [ -d venv ] && [ -z "$VIRTUAL_ENV" ]; then
    source venv/bin/activate
fi

# 모델 파일 체크
if [ ! -f "$QWEN_MODEL" ]; then
    echo "❌ ERROR: 모델 파일 없음: $QWEN_MODEL"
    echo "   QWEN_MODEL 환경변수로 경로 지정"
    exit 1
fi

# llama-server 체크
if [ ! -f "$LLAMA_BIN" ]; then
    echo "❌ ERROR: llama-server 없음: $LLAMA_BIN"
    echo "   LLAMA_BIN 환경변수로 경로 지정"
    exit 1
fi

# 절전 잠금 (Termux)
if command -v termux-wake-lock >/dev/null 2>&1; then
    termux-wake-lock 2>/dev/null
fi

echo "================================================"
echo "  EVE v39 시작"
echo "  Qwen 모델: $QWEN_MODEL"
echo "  Qwen 포트: $QWEN_PORT"
echo "  EVE 포트: $EVE_PORT"
echo "================================================"

# 1. llama-server 백그라운드 시작
echo ""
echo "[1/2] Qwen 서버 시작..."
"$LLAMA_BIN" \
    -m "$QWEN_MODEL" \
    -t 4 \
    -c 4096 \
    --cache-type-k q4_0 \
    --cache-type-v q4_0 \
    --host 127.0.0.1 \
    --port "$QWEN_PORT" \
    --log-disable \
    > qwen_server.log 2>&1 &
QWEN_PID=$!
echo "  → Qwen 서버 PID: $QWEN_PID (로그: qwen_server.log)"

# 2. 서버 헬스체크 대기 (최대 60초)
echo ""
echo "[2/2] Qwen 서버 응답 대기..."
for i in {1..60}; do
    if curl -s "http://127.0.0.1:$QWEN_PORT/health" > /dev/null 2>&1; then
        echo "  ✅ Qwen 서버 응답 OK ($i초)"
        break
    fi
    sleep 1
    if [ $i -eq 60 ]; then
        echo "  ❌ Qwen 서버 응답 X (60초 대기)"
        kill $QWEN_PID 2>/dev/null
        exit 1
    fi
done

# 3. EVE 백엔드 시작 (WebSocket 서버)
echo ""
echo "[3/3] EVE 백엔드 시작..."
echo "  → 연결: ws://localhost:$EVE_PORT"
echo "  → Qwen 활성: ws://127.0.0.1:$QWEN_PORT"
echo ""
echo "================================================"
echo "  EVE v39 실행 중. Ctrl+C로 종료."
echo "================================================"

# trap으로 깔끔하게 종료
trap "echo ''; echo '종료 중...'; kill $QWEN_PID 2>/dev/null; exit 0" INT TERM

# EVE 서버 시작 (포그라운드)
EVE_QWEN_URL="http://127.0.0.1:$QWEN_PORT" \
EVE_USE_QWEN=true \
python3 v36_modules/airi_server.py \
    --port "$EVE_PORT" \
    --autosave "$HOME/eve_state.ckpt" \
    --autosave-interval 600

# 종료 시 Qwen 서버도 종료
kill $QWEN_PID 2>/dev/null
echo "EVE v39 종료됨"
