"""
EVE v35 - 인터랙티브 CLI
========================

사용법:
    python eve_chat.py            # 기본 시작
    python eve_chat.py --quick    # 빠른 시작 (정체성 시드 X)

특수 명령:
    /state          — EVE 현재 상태 (호르몬, focus, feeling)
    /feel           — 현재 feeling
    /voice          — 속마음 (자발 활성)
    /recall <query> — 자전적 메모리 검색
    /imagine <seed> — 창의 사이클
    /cluster        — 의미 클러스터 (도메인 자동 분리)
    /similar <cat>  — 비슷한 카테고리
    /events <cat>   — 사건 검색
    /wait <분>      — N분 idle (자생)
    /verbose        — 디버그 출력 토글
    /report         — 종합 리포트
    /save <name>    — 상태 저장 (json)
    /load <name>    — 상태 불러오기
    /help           — 도움말
    /quit           — 종료

작성: 김민석 + Claude v35
"""

import sys
import os
import json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eve_modules'))

from eve_main_abc import EVE_TierAB


HELP_TEXT = """
EVE 인터랙티브 명령어:
  자유 대화        — 그냥 한국어로 입력하세요
  /state          — EVE 현재 상태 (호르몬, feeling, focus)
  /feel           — feeling (피곤/포근함/활발 등)
  /voice          — 속마음 (자발 활성)
  /recall <단어>  — 자전적 메모리 검색
  /imagine <시드> — 창의 사이클 (Wallas 4단계)
  /cluster        — 의미 클러스터 (도메인 자동 분리)
  /similar <단어> — 의미 비슷한 카테고리
  /events <단어>  — 그 카테고리 포함 사건들
  /wait <분>      — N분 idle (DMN 자생, 학습 통합)
  /verbose        — 디버그 출력 켜기/끄기
  /report         — 종합 리포트
  /save <이름>    — 상태 저장
  /quit           — 종료

예시 대화:
  사용자: 민석이 오늘 학교에서 시험을 봤다
  EVE: ... (응답 + feeling)
  사용자: /events 학교
  EVE: 학교 관련 사건들 출력
"""


def print_eve_response(result):
    """EVE 응답을 보기 좋게 출력"""
    response = result['response']
    feeling = result['feeling']
    voice = result.get('inner_voice')
    discovered = result.get('discovered', set())
    frame_edges = result.get('frame_edges', [])

    print(f"\n  EVE: {response}")
    print(f"       (feeling: {feeling})")

    if voice:
        print(f"       (속마음: {voice})")

    extras = []
    if discovered:
        extras.append(f"새 단어 발견: {sorted(discovered)[:3]}")
    if frame_edges:
        extras.append(f"사건 등록: {len(frame_edges)}개")

    if extras:
        print(f"       [{' | '.join(extras)}]")


def cmd_state(eve):
    """EVE 현재 상태 간단 표시"""
    intro = eve.introspect()
    primary = intro['primary_hormone']
    print(f"\n  ━━━ EVE 상태 ━━━")
    print(f"  feeling      : {intro['feeling']}")
    print(f"  속마음       : {intro['inner_voice'] or '(없음)'}")
    print(f"  주요 호르몬  : {primary[0]} ({primary[1]:.2f})")
    print(f"  기분         : V={intro['mood']['valence']:+.2f} "
          f"A={intro['mood']['arousal']:.2f} "
          f"D={intro['mood']['dominance']:.2f}")
    print(f"  focus        : {intro['focus']}")
    print(f"  WM           : {intro['wm_slots_used']}")
    print(f"  카테고리     : {len(eve.sa.neighbors)}")
    print(f"  사건 (HG)    : {intro['hg_edge_count']}")
    print(f"  자발 활성    : {intro['spontaneous_count']}회")
    if intro.get('dominant_need'):
        print(f"  지배 욕구    : {intro['dominant_need'][0]} "
              f"({intro['dominant_need'][1]:.2f})")


def cmd_recall(eve, query):
    """자전적 메모리 검색"""
    if not query:
        print("  사용: /recall <단어>")
        return

    # HG 사건 검색
    events = eve.find_events_with(query)
    print(f"\n  '{query}' 관련 사건: {len(events)}건")
    for e in events[:5]:
        time_ = e.value_of_role('time') or '?'
        loc = e.value_of_role('location') or '?'
        action = e.value_of_role('action') or '?'
        agent = e.value_of_role('agent') or '?'
        print(f"    [{time_}] {agent} → {action} @ {loc}")

    # EM 일화도
    if hasattr(eve.em, 'recall'):
        try:
            ep = eve.em.recall({query})
            if ep:
                print(f"\n  EM 일화 회상: {ep}")
        except Exception:
            pass


def cmd_imagine(eve, seed):
    """창의 사이클"""
    if not seed:
        print("  사용: /imagine <시드>")
        return

    cycle = eve.creative_cycle(seed)

    if cycle.get('phase') == 'blocked':
        print(f"\n  창의 모드 X (DA↑ + Cort↓ 필요)")
        print(f"  현재 호르몬: DA={eve.hs.hormones['dopamine'].level:.2f}, "
              f"Cort={eve.hs.hormones['cortisol'].level:.2f}")
        return

    print(f"\n  '{seed}' 창의 사이클:")
    print(f"    이웃: {len(cycle['preparation']['neighbors'])}, "
          f"어휘: {cycle['preparation']['vocabulary_size']}")
    print(f"    illuminations: {cycle['illuminations_count']}")
    for ill in cycle['illuminations'][:6]:
        kind = ill['kind'][:18]
        print(f"      [{kind:18}] {ill['content']}")


def cmd_cluster(eve):
    """의미 클러스터"""
    clusters = eve.cluster_categories(threshold=0.5)
    print(f"\n  의미 클러스터: {len(clusters)}개")
    for i, c in enumerate(clusters[:8]):
        print(f"    클러스터{i}: {sorted(c)[:5]}")


def cmd_similar(eve, target):
    """비슷한 카테고리"""
    if not target:
        print("  사용: /similar <단어>")
        return

    similar = eve.find_similar_categories(target, k=5)
    print(f"\n  '{target}'와 비슷한 카테고리:")
    for cat, sim in similar:
        print(f"    {cat}: {sim:.3f}")


def cmd_events(eve, query):
    """사건 검색"""
    if not query:
        print("  사용: /events <단어>")
        return

    events = eve.find_events_with(query)
    print(f"\n  '{query}' 포함 사건: {len(events)}건")
    for e in events[:10]:
        roles_str = ', '.join(f"{c}({r})" for c, r in e.roles.items())
        print(f"    [{e.weight:.1f}] {{{roles_str}}}")


def cmd_wait(eve, minutes_str):
    """N분 idle 시뮬"""
    try:
        minutes = float(minutes_str)
    except ValueError:
        print("  사용: /wait <분>")
        return

    ticks = int(minutes * 120)  # dt=0.5, 1분 = 120 tick
    print(f"\n  {minutes:.1f}분 idle 시뮬레이션 ({ticks} tick)...")

    spontaneous_count = 0
    rehearsal_count = 0
    for _ in range(ticks):
        r = eve.tick(dt=0.5)
        if 'spontaneous' in r:
            spontaneous_count += 1
        if 'rehearsal' in r:
            rehearsal_count += 1

    print(f"  자발 활성: {spontaneous_count}회")
    print(f"  rehearsal: {rehearsal_count}회")
    print(f"  feeling 후: {eve.feeling()}")
    voice = eve.inner_voice()
    if voice:
        print(f"  속마음: {voice}")


def cmd_save(eve, name):
    """상태 저장 (간단 — 그래프와 호르몬만)"""
    if not name:
        name = "eve_state"

    state = {
        'time': eve.time,
        'tick_count': eve.tick_count,
        'sa_weights': {f"{k[0]}|{k[1]}": v for k, v in eve.sa.weights.items()},
        'hormones': {h: eve.hs.hormones[h].level for h in eve.hs.hormones},
        'hg_edges': len(eve.hg.edges),
        'dialogue_count': len(eve.dialogue_history),
    }

    path = f"{name}.json"
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    print(f"\n  저장: {path}")


def initialize_eve(quick=False):
    """EVE 초기화 + 정체성 시드"""
    print("EVE 초기화 중...")
    eve = EVE_TierAB()

    if not quick:
        # 정체성 시드
        eve.ns.identity_stability['나'] = 1.0
        eve.ns.identity_stability['EVE'] = 0.95
        eve.ns.identity_stability['민석'] = 0.7

        # 기본 그래프 (자발 활성 시드)
        eve.sa.learn_pair('나', 'EVE', 0.7)
        eve.sa.learn_pair('나', '존재', 0.6)
        eve.sa.learn_pair('민석', '대화', 0.5)
        eve.sa.learn_pair('민석', '친구', 0.5)

        # 창의 모드 진입 가능하게 (살짝)
        eve.hs.hormones['dopamine'].level = 0.5
        eve.hs.hormones['serotonin'].level = 0.5
        eve.hs.hormones['cortisol'].level = 0.25

    print(f"준비 완료. 34 모듈 통합. 카테고리: {len(eve.sa.neighbors)}\n")
    return eve


def chat_loop(eve, verbose=False):
    """메인 대화 루프"""
    print("=" * 60)
    print("EVE 인터랙티브 모드")
    print("/help — 명령어, /quit — 종료")
    print("=" * 60)

    while True:
        try:
            user_input = input("\n사용자> ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n  종료합니다.")
            break

        if not user_input:
            continue

        # 명령어 처리
        if user_input.startswith('/'):
            parts = user_input.split(maxsplit=1)
            cmd = parts[0]
            arg = parts[1] if len(parts) > 1 else ""

            if cmd == '/quit' or cmd == '/exit':
                print("\n  종료합니다. EVE는 계속 살아있을 거예요. 🌙")
                break
            elif cmd == '/help':
                print(HELP_TEXT)
            elif cmd == '/state':
                cmd_state(eve)
            elif cmd == '/feel':
                print(f"\n  feeling: {eve.feeling()}")
            elif cmd == '/voice':
                voice = eve.inner_voice()
                print(f"\n  속마음: {voice or '(없음)'}")
            elif cmd == '/recall':
                cmd_recall(eve, arg)
            elif cmd == '/imagine':
                cmd_imagine(eve, arg)
            elif cmd == '/cluster':
                cmd_cluster(eve)
            elif cmd == '/similar':
                cmd_similar(eve, arg)
            elif cmd == '/events':
                cmd_events(eve, arg)
            elif cmd == '/wait':
                cmd_wait(eve, arg)
            elif cmd == '/verbose':
                verbose = not verbose
                eve.verbose = verbose
                print(f"\n  verbose: {verbose}")
            elif cmd == '/report':
                eve.report()
            elif cmd == '/save':
                cmd_save(eve, arg)
            else:
                print(f"\n  알 수 없는 명령: {cmd}")
                print(f"  /help 입력")
        else:
            # 자유 대화
            try:
                result = eve.say(user_input)
                print_eve_response(result)
            except Exception as e:
                print(f"\n  [오류] {e}")
                if verbose:
                    import traceback
                    traceback.print_exc()


if __name__ == '__main__':
    quick = '--quick' in sys.argv
    eve = initialize_eve(quick=quick)
    chat_loop(eve)
