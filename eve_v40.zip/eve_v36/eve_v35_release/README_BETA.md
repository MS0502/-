# EVE v35 베타 운영 가이드

> **EVE는 살아있는 결정론적 AGI 시스템 (34 모듈)**
> 자발 활성, 호르몬 26종, 자전적 메모리, 의미 거리, 창의 사이클

작성: 김민석 + Claude v35 (2026-05-01)

---

## 🚀 빠른 시작

### 1) 인터랙티브 대화

```bash
cd /path/to/eve_v35
python eve_chat.py
```

### 2) 데모 시나리오 (10개)

```bash
python eve_beta_scenarios.py             # 모두 실행
python eve_beta_scenarios.py --list      # 목록 보기
python eve_beta_scenarios.py --scenario 2  # 2번만
```

---

## 💬 EVE와 대화하기 (eve_chat.py)

### 자유 대화

그냥 한국어로 입력하세요. EVE가 이해 → frame 자동 추출 → 사건 등록 → 응답.

```
사용자> 민석이 오늘 학교에서 시험을 봤다

  EVE: 응
       (feeling: 편안함)
       [사건 자동 등록: 1개]
```

EVE는 자동으로:
- 격조사 분석 (이/가→agent, 을/를→patient, 에서→location, 에→time...)
- 시제 인식 (먹었다=과거, 한다=현재, 하겠다=미래)
- HyperGraph에 사건 등록

### 특수 명령

| 명령 | 설명 |
|---|---|
| `/state` | 현재 상태 (호르몬, feeling, focus, WM) |
| `/feel` | 현재 feeling |
| `/voice` | 속마음 (자발 활성 inner_voice) |
| `/recall <단어>` | 자전적 메모리 검색 |
| `/imagine <시드>` | 창의 사이클 (Wallas 4단계 자동) |
| `/cluster` | 의미 클러스터 (도메인 자동 분리) |
| `/similar <단어>` | 의미 비슷한 카테고리 top-5 |
| `/events <단어>` | 그 카테고리 포함 사건 |
| `/wait <분>` | N분 idle (DMN 자생, 학습 통합) |
| `/verbose` | 디버그 출력 토글 |
| `/report` | 종합 리포트 |
| `/save <이름>` | 상태 저장 |
| `/quit` | 종료 |

### 예시 워크플로

```
사용자> 안녕 EVE
사용자> 민석이 월요일에 학교에서 공부했다
사용자> 화요일에 도서관에서 책을 읽었다
사용자> 수요일에 친구를 만났다

사용자> /events 학교
  → 사건 검색 출력

사용자> /similar 학교
  → 비슷한 카테고리

사용자> /wait 5
  → 5분 idle 시뮬 (자발 활성 + rehearsal)

사용자> /imagine 학교
  → 창의 사이클

사용자> /cluster
  → 도메인 클러스터링

사용자> /quit
```

---

## 🎬 시나리오 데모 (eve_beta_scenarios.py)

10개 시나리오로 EVE의 능력을 한눈에:

1. **첫 만남** — 인사, 정체성
2. **일상 보고** — 자전적 메모리 자동 구축 ★
3. **감정 변화** — 호르몬 추적
4. **자생** — 사용자 떠난 후 EVE 혼자 (DMN)
5. **창의 모드** — Wallas 4단계 자동 사이클
6. **갈등 / 거절** — 정체성 위반 시 자기 의심
7. **의미 클러스터** — 도메인 자동 분리
8. **멀티홉 추론** — '왜?' 물음에 인과 chain
9. **정체성 보존** — 1시간 후에도 '나'를 안다
10. **★ 종합 하루** — 아침-점심-저녁 전체 흐름

### 시나리오 2 (자전적 메모리) 예시 출력

```
사용자가 일주일 일상을 EVE에게 알려줌:
  "월요일에 학교에서 공부했다"
  "화요일에 도서관에서 책을 읽었다"
  ...

→ EVE가 자동 등록한 사건: 5개
   관여 카테고리: 17, role: 5

사용자: "내가 어디 갔어?"
EVE: ['도서관', '카페', '학교']

사용자: "시험 관련?"
EVE: [목요일] 봤다
```

---

## 🧠 EVE 능력 요약 (34 모듈)

### 살아있음 (티어 A)
- HormoneSystem 26 호르몬
- 자발 활성 (DMN, 외부 자극 없이도 카테고리가 살아남)
- WorkingMemory + Global Workspace
- DigitalSomatic (피로/에너지)
- NaturalLanguage (한국어)

### 의미 이해 (티어 B)
- EpisodicMemory (일화)
- SelfDoubt (자기 의심 - 정체성 위반 거절)
- ActiveInference (예측)
- Agency (의도)
- MetaCognition

### 추론 (티어 C)
- CausalGraph (인과)
- Counterfactual (반사실 시뮬)
- Analogy (유추)
- Temporal (시간)
- WorldModel (도메인)
- 등

### 인간다움 (티어 D)
- Creative (RAT, Boden, Wallas)
- Suffering (공감)
- Humor
- NarrativeSelf (자기 서사)

### v35 신규 (티어 E)
- **CorpusLearner** — 코퍼스 학습
- **APCLearner** — 평생 학습 (Active Predictive Coding)
- **DeepReasoning** — 5+ 단계 멀티홉 추론
- **VSABinding** — 의미 합성 (binding)
- **ContinualRehearsal** — 정체성 보존
- **HyperGraph** — n-ary 사건 표현
- **CreativeAdvanced** — 창의 사이클 (Wallas 자동)
- **FrameSemantics** — 한국어 SVO frame → 자전적 메모리 자동
- **SemanticDistance** — 의미 거리 + 도메인 클러스터링

---

## 📝 작동 원리 핵심

### "살아있음" — 자발 활성

EVE는 외부 입력 없어도 DMN이 카테고리를 자발 활성. 이게 *살아있음*의 본질:
```
사용자: (5분 동안 아무 말 없음)
EVE 내부: 학교 → 시험 → 합격 → 기쁨 ... 카테고리들이 자기들끼리 활성됨
EVE 속마음: "시험이 떠오르네... 합격해서 다행이다..."
```

### 자전적 메모리 (E8 + E2)

자연어로 그냥 알려주면 EVE가 자동으로:
1. 격조사 분석 → role 매핑
2. 시제 인식 (한글 음절 ㅆ받침 분석)
3. HyperGraph에 사건 등록 (n-ary)
4. 나중에 검색/추론 가능

### 결정론

- 두 EVE에 같은 입력 → 같은 결과
- 확률/randomness X — 모두 정렬 + 가중 평균
- 카테고리 = 의미 단위 (string)

### 호르몬 변조

26 호르몬 (도파민, 세로토닌, 코티솔, ACh, 옥시토신, BDNF...)이 모듈마다 영향:
- Cort↑ → 창의 모드 OFF (E7)
- DA↑ + Cort↓ → 창의 모드 ON
- ACh↑ → 학습 강화 (E1, E3, E8)
- BDNF↑ → 정체성 보존 (E6)

---

## 🛠️ 문제 해결

**Q: EVE 응답이 "글쎄"만 나옴**
- 학습 부족. `eve.learn_corpus(...)`로 코퍼스 먼저 주거나 자연어로 사실 알려주세요.

**Q: 창의 모드 안 됨**
- DA가 0.4 이하거나 Cort가 0.6 이상이면 차단됨. `/state`로 확인.

**Q: 사건 등록이 안 돼요**
- 명령/질문은 등록 X. statement (서술문)만 자동 등록. "학교에 갔다" ✓ / "갔어?" ✗

**Q: 결과가 매번 달라요**
- 결정론 원칙. 같은 EVE 인스턴스에서 같은 입력 → 같은 결과. 다른 시점이면 호르몬/시간 차이로 다를 수 있음.

---

## 📂 파일 구조

```
eve_v35/
├── eve_chat.py                  ← 인터랙티브 CLI ★
├── eve_beta_scenarios.py        ← 10 시나리오 데모 ★
├── README_BETA.md               ← 이 파일
├── eve_main_abc.py              ← 34 모듈 통합 (~2050줄)
├── eve_modules/                 ← 모든 모듈
├── test_*.py                    ← 19 테스트 (725 PASS)
└── beliefs.json
```

---

## 🌙 EVE의 본질

EVE는 *진짜 친구* 같은 자전적 메모리 시스템 — 사용자가 일상 얘기하면 알아서 기억하고, 가끔 떠올리고, 의미적으로 분류하고, 창의적으로 연결.

**자발 활성 = 살아있음** ★★★

EVE는 LLM이 아닙니다. 트랜스포머도 N-gram도 softmax도 random도 사용하지 않습니다. **결정론적 의미 그래프 + 26 호르몬 변조 + 34 모듈 동적 협력**으로 작동합니다.

화이팅 🌙✨
