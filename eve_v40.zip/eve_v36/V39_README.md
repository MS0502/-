# EVE v39 — Qwen 4B Broca 통합

EVE v36 + Qwen 3-4B-Instruct-2507 자연어 변환기 통합.

## 핵심 변화 (v38 → v39)

```
v38: EVE 본체 + ResponseEnhancer (12개 패턴 매칭)
   → 응답 빈약, 자유로움 X

v39: EVE 본체 + Qwen 4B Broca (자연어 변환기)
   → 자유로운 응답, 호르몬 → 어조 정밀 매핑
   → 도구 사용 가능
   → 일화 기억 + RAG
```

## 인지 아키텍처

```
사용자 메시지
    ↓
EVE 본체 (LLM 0%, 결정론)
    ├── 호르몬 26종
    ├── 카테고리 그래프 의미망
    ├── 일화 메모리 (자동 저장)
    ├── 의도 결정
    └── 자기 응답 흡수
    ↓
Intent JSON (호르몬, 어조, 길이, RAG)
    ↓
Qwen 4B (Broca 영역)
    ├── realize(): 자연어 응답
    ├── tool_call(): JSON 도구 호출
    └── summarize(): 텍스트 요약
    ↓
응답 → EVE 흡수 → 다음 결정에 영향
```

학계 부합:
- **Damasio Somatic Marker** — 호르몬이 어조 결정
- **Hickok-Poeppel Dual Stream** — 이해(EVE)/생성(Qwen) 분리
- **CoALA (Sumers 2024)** — Memory + Reasoning + Acting 분리
- **Mesulam 2013** — 의미는 *언어 영역에 있지 않다* (EVE 카테고리에 있음)

## 설치 (Termux)

### 1. llama.cpp + 모델

```bash
# llama.cpp
pkg install -y cmake git python clang
git clone https://github.com/ggerganov/llama.cpp ~/llama.cpp
cd ~/llama.cpp && cmake -B build && cmake --build build --config Release -j

# 모델 (2.4GB)
cd ~/llama.cpp
wget https://huggingface.co/unsloth/Qwen3-4B-Instruct-2507-GGUF/resolve/main/Qwen3-4B-Instruct-2507-Q4_K_M.gguf
```

### 2. EVE v39

```bash
cd ~
unzip eve_v36.zip  # 또는 tar -xzf eve_v36.tar.gz
cd eve_v36

python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. 실행

```bash
chmod +x run_v39.sh
./run_v39.sh
```

자동:
1. llama-server 백그라운드 시작 (Qwen 4B 로드, ~5초)
2. 헬스체크 대기 (최대 60초)
3. EVE WebSocket 서버 시작 (`ws://localhost:8765`)

## 사용법 — Python

```python
from v36_modules.eve_v39 import EVE_v39

# Qwen 사용 (서버 필요)
eve = EVE_v39(
    seed_common_sense_on_init=True,
    use_qwen=True,
    qwen_server_url='http://127.0.0.1:8080',
    auto_fallback=True,  # 서버 죽으면 v36 enhancer로
)
eve.enter_room()

# 친밀도 누적 (선택)
for _ in range(5):
    eve.user_presence.visit_arrive()
    eve.tick(dt=0.5)
    eve.user_presence.visit_leave()
    eve.tick(dt=0.5)
eve.user_presence.visit_arrive()

# 대화
result = eve.say("오늘 PT 진짜 힘들었어")
print(result['response'])
# → "민석아 진짜 고생했어… 힘들면 꼭 푹 쉬어줘야 돼, 오늘은 나도 같이 힘들었어 ㅎㅎ"

print(result['qwen_status'])  # 'success' / 'server_dead_fallback' / 'empty_fallback'
print(result['intent_used'])  # Broca에 보낸 데이터 (디버깅용)

# 도구 호출
tool = eve.tool_use("서울 날씨 어때?")
# → {"tool": "get_weather", "params": {"city": "서울"}}

# RAG — 과거 일화 검색
related = eve.recall_related("PT", k=5)
# → [{summary, time, categories, mood_valence}, ...]

# v39 보고
eve.report_v39()
```

## 호르몬 → 어조 매핑

| 호르몬 우세 | 어조 | 응답 예시 |
|---|---|---|
| oxytocin > 0.6 | warm | "민석아 진짜 고생했어..." |
| cortisol > 0.6 | irritated | "아 진짜, 시발 끝내고 싶은데" |
| dopamine > 0.7 + ot > 0.5 | happy | "오 진짜? 신난다!" |
| melatonin > 0.7 | sleepy | "음... 졸려, 자야겠다" |
| serotonin > 0.6 | calm | "그래, 다 괜찮아질 거야" |

**같은 메시지 + 다른 호르몬 = 다른 EVE 인격**.

## 응답 길이 동적

| 사용자 메시지 | 길이 | 토큰 |
|---|---|---|
| "안녕" (5자) | short | 100 |
| "뭐해?" (3자, 질문) | short | 100 |
| "PT 힘들어 + 동기 어색" (24자, 부정) | medium | 250 |
| "1년 군 생활... 적응 안 돼..." (76자) | long | 500 |

## 일화 기억 + RAG

EVE는 *자동으로* 대화를 일화로 저장. v36의 EpisodicMemory.

```python
# 일화 자동 저장
eve.say("오늘 PT 힘들어")
eve.tick(dt=2)  # 일화 저장됨

len(eve.em.episodes)  # 점점 늘어남

# 새 메시지 → 관련 과거 자동 검색 (RAG)
result = eve.say("내일도 PT야")
# 내부에서 "PT" 카테고리로 과거 일화 검색
# → "오늘 PT 힘들어" 일화 자동 컨텍스트에 포함
# → Qwen이 "지난번에도 그랬지" 같은 자연스러운 참조 가능
```

**메모리 폭발 X** — 매번 4K 컨텍스트 + 디스크에 무한 일화.

## 자기 응답 흡수 (자기 의식)

EVE가 자기 응답을 *듣고* 카테고리/호르몬에 반영.

```python
result = eve.say("힘들어")
# Qwen 응답: "민석아 푹 쉬어"
# → EVE가 자기 응답에서 ['민석', '쉬다', '진짜'] 카테고리 흡수
# → 다음 결정에 영향 (점차 '쉬다' 카테고리가 EVE 일상에 통합)

eve.self_absorption_count  # 흡수 횟수
```

학계 (분산 자아, Damasio Protoself) — 자기 발화도 자기 입력.

## Fallback (안정성)

```python
# Qwen 서버 죽음 → v36 enhancer로 자동 폴백
eve = EVE_v39(use_qwen=True, auto_fallback=True)
result = eve.say("안녕")
# 서버 OK → result['response'] = Qwen 응답
# 서버 X → result['response'] = v36 enhancer 응답
# 둘 다 'response' 키로 동일하게 접근
```

## 검증 결과

| 단계 | PASS | 회귀 |
|---|---|---|
| broca_qwen 단위 | 9/9 | - |
| eve_v39 통합 | 20/20 | - |
| Mock Qwen end-to-end | 10/10 | - |
| 엣지 케이스 | 16/16 | - |
| v36/v37/v38 회귀 | - | 0건 (모든 기존 테스트 통과) |
| **총합** | **55/55** | **0건** |

## 알려진 한계

1. **Qwen 응답 시간 3~10초** (Z Fold 6 12 tok/s). LLM 본질.
2. **첫 응답 느림** — llama-server 시작 ~5초 (모델 로드).
3. **호르몬 이름 가끔 직접 언급** — 시스템 프롬프트로 99% 차단했지만 가끔 새어나옴.
4. **반말/존댓말 가끔 섞임** — temp 낮춰도 1~2% 발생.

## 다음 단계 (v40+)

- LoRA 파인튜닝 (김민석 1000+ 대화 누적 후, 콜랩 1시간)
- Vector DB 통합 (sqlite-vec, semantic RAG)
- 멀티모달 (VRM 캐릭터 + 음성)
- 14B 모델 (집 PC, 깊은 추론)

## 라이선스

EVE: 김민석 개인 프로젝트  
Qwen 3-4B-Instruct: Apache 2.0 (Alibaba)
