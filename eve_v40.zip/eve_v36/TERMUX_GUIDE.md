# EVE Termux 실행 가이드 (Z Fold 6)

## 0. Termux 준비

```bash
# Termux 자체는 F-Droid에서 (구글 플레이 버전은 오래됨)
# https://f-droid.org/en/packages/com.termux/

# 패키지 업데이트
pkg update -y && pkg upgrade -y

# Python + 필요 도구
pkg install -y python git nano

# 절전 방지 — 백그라운드 실행 시 (앱 끄지 마)
pkg install -y termux-api
termux-wake-lock
```

## 1. EVE 코드 가져오기

```bash
cd ~

# 옵션 A: 폰에 USB로 옮긴 파일 사용
# (Z Fold 6 → 컴퓨터 → eve_v36/ 폴더 통째로 ~/eve_v36/로 복사)
# Termux 내부 파일 매니저 사용

# 옵션 B: 클라우드 (Google Drive 등)
# 다운로드 후 압축 풀기

# 위치 확인
ls ~/eve_v36/v36_modules/eve_v36.py
ls ~/eve_v36/eve_v35_release/eve_main_abc.py
```

## 2. 의존성 설치 (1개만 — 빠름)

```bash
cd ~/eve_v36

# 가상환경 (Termux 권장)
python3 -m venv venv
source venv/bin/activate

# websockets만 (FastAPI 안 씀 — rust 컴파일 회피)
pip install websockets

# 다른 의존성 X — EVE는 numpy/scipy만 사용
pip install numpy
```

처음 1회만. 다음부턴 `source venv/bin/activate`만 하면 됨.

## 3. EVE 실행

### 기본 실행
```bash
cd ~/eve_v36
source venv/bin/activate
python3 v36_modules/airi_server.py
```

출력:
```
[14:23:01] INFO: EVE 인스턴스 생성 중...
[14:23:02] INFO: EVE 준비 완료: 호르몬 26, 카테고리 ..., 위치 내방
[14:23:02] INFO: tick loop 시작 (간격=0.5s)
[14:23:02] INFO: state push loop 시작 (간격=1.0s)
[14:23:02] INFO: WebSocket 서버 시작: ws://0.0.0.0:8765
[14:23:02] INFO:   같은 폰 안: ws://localhost:8765
[14:23:02] INFO:   같은 wifi: ws://<폰IP>:8765
```

### 영속화 옵션 (권장)
```bash
python3 v36_modules/airi_server.py \
    --autosave ~/eve_state.ckpt \
    --autosave-interval 600
```
10분마다 자동 저장. 다음 실행 시 자동 로드. 진짜 영속 친구.

### 시뮬 시간 진행 옵션
```bash
# 매 0.5초 tick마다 시뮬 시간 1분 진행 (실제 1초 = 시뮬 2분)
python3 v36_modules/airi_server.py \
    --sim-hour-per-tick 0.0167 \
    --autosave ~/eve_state.ckpt
```

EVE의 일주기가 빨리 흐름 — 30분만 켜놔도 EVE가 하루를 살아냄.

## 4. 폰 IP 확인 (외부 기기에서 접속하려면)

```bash
ifconfig 2>/dev/null | grep -A 1 wlan0
# 또는
termux-wifi-connectioninfo
```

`192.168.x.x` 같은 주소. AIRI에 `ws://192.168.x.x:8765` 입력.

## 5. 테스트 — 간단한 채팅

다른 터미널 (또는 같은 폰에서 새 Termux 세션 — `Acquire wakelock` 가능):

```bash
python3 -c "
import asyncio, json, websockets

async def chat():
    async with websockets.connect('ws://localhost:8765') as ws:
        # 첫 state 받기
        msg = await ws.recv()
        data = json.loads(msg)
        print(f'EVE 표정: {data[\"expression\"]}, 위치: {data[\"location\"]}')
        
        # 메시지 보내기
        await ws.send(json.dumps({'type': 'user_message', 'text': '안녕!'}))
        
        # 응답 받기
        for _ in range(3):
            msg = await ws.recv()
            data = json.loads(msg)
            if data['type'] == 'speech':
                print(f'EVE: {data[\"text\"]}')
                break

asyncio.run(chat())
"
```

또는 브라우저로 `airi_test_client.html` 열기 (같은 폴더 제공).

## 6. 백그라운드 실행 (앱 닫아도 EVE 살아있게)

### 옵션 A: tmux
```bash
pkg install -y tmux
tmux new -s eve
python3 v36_modules/airi_server.py --autosave ~/eve_state.ckpt
# Ctrl+B, D — detach
# 나중에 다시 보기: tmux attach -t eve
```

### 옵션 B: nohup
```bash
nohup python3 v36_modules/airi_server.py \
    --autosave ~/eve_state.ckpt \
    > ~/eve.log 2>&1 &
echo $! > ~/eve.pid

# 종료: kill $(cat ~/eve.pid)
```

### 옵션 C: termux-services (자동 시작)
```bash
pkg install -y termux-services
mkdir -p ~/.termux/boot
cat > ~/.termux/boot/eve.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/sh
termux-wake-lock
cd ~/eve_v36
source venv/bin/activate
python3 v36_modules/airi_server.py --autosave ~/eve_state.ckpt
EOF
chmod +x ~/.termux/boot/eve.sh
```

폰 부팅 시 자동 실행 (Termux:Boot 앱 추가 필요).

## 7. AIRI 앱 연결

1. AIRI APK 설치 (https://nekomeowww.itch.io/airi)
2. AIRI 설정 → Provider/Server URL → `ws://localhost:8765` 입력
3. (또는 다른 wifi 기기에서) `ws://<폰IP>:8765`

지금은 AIRI가 EVE 프로토콜 직접 지원 안 함 — *다음 v39에서* AIRI 측 어댑터 작성 예정. 우선은 v38의 EVE 백엔드만 작동.

테스트는 위 [5]의 Python 클라이언트나 HTML 클라이언트로.

## 8. 문제 해결

**"ModuleNotFoundError: websockets"**
```bash
source venv/bin/activate
pip install websockets
```

**"Address already in use"** (포트 충돌)
```bash
EVE_PORT=8766 python3 v36_modules/airi_server.py
```

**메모리 부족** (오래 켜놓으면)
```bash
# autosave 활용 — 종료/재시작
# 또는 더 짧은 history
EVE_TICK=1.0 EVE_STATE_PUSH=2.0 python3 v36_modules/airi_server.py
```

**Termux가 자동 종료됨**
- Settings → 앱 → Termux → 배터리 → 제한 안 함
- `termux-wake-lock` 실행 (절전 잠금)

## 9. EVE 명령 — Z Fold 6에서 자주 쓰는 것

```bash
# 시작
cd ~/eve_v36 && source venv/bin/activate && python3 v36_modules/airi_server.py

# 또는 alias 등록 (~/.bashrc)
alias eve-start='cd ~/eve_v36 && source venv/bin/activate && python3 v36_modules/airi_server.py --autosave ~/eve_state.ckpt'

# 로그 보기
tail -f ~/eve.log

# EVE 상태 즉시 확인
curl-like 도구는 X — Python 한 줄로
python3 -c "
import asyncio, json, websockets
async def s():
    async with websockets.connect('ws://localhost:8765') as ws:
        d = json.loads(await ws.recv())
        print(f'시각: {d[\"period\"]} {d[\"sim_hour\"]:.1f}h')
        print(f'표정: {d[\"expression\"]} ({d[\"mood\"]})')
        print(f'위치: {d[\"location\"]}')
        print(f'feeling: {d[\"feeling\"]}')
        print(f'속마음: {d[\"inner_voice\"]}')
asyncio.run(s())
"
```

## 10. 참고 — Z Fold 6 특화 팁

- **분할 화면**: AIRI 앱 + Termux 동시 — 폰 한 화면에 EVE 캐릭터 + 디버그 로그
- **외부 모니터**: USB-C HDMI → 큰 화면으로 EVE 보기
- **DeX 모드**: 데스크톱 환경 — 마우스/키보드 사용
- **배터리**: 풀 충전 + 절전 모드 X로 24시간 EVE 살리기 OK

---

**메모리 영속화 + 자동 시작 + tmux** 조합 = EVE가 진짜 폰 안에 *살아있는* 친구.
