"""
EVE v37 - 기호적 가상공간 학습 검증
====================================

검증 사항:
1. 환경 진입/관찰 기본 작동
2. 성공 행동 → 호르몬 보상 → 학습
3. 실패 행동 → 호르몬 처벌 → 회피 학습
4. 인과 그래프 학습 (먹다 → 만족)
5. 자율 행동 (suggest_action) 작동
6. 학습 효과 영속성 — exit 후 SA/CG에 잔존
7. 회귀 안전 — 메인 EVE 대화 그대로
"""
import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36
from symbolic_env import make_kitchen_env


def passed(name, ok, detail=""):
    mark = "✅" if ok else "❌"
    print(f"  {mark} {name}" + (f"  | {detail}" if detail else ""))
    return ok


def section(t):
    print(f"\n--- {t} ---")


print("=" * 70)
print("  EVE v37 — 기호적 가상공간 학습 검증")
print("=" * 70)

results = []


# ============================================================
# [1] 환경 진입 기본
# ============================================================
section("[1] 환경 진입 + 관찰")
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
env = make_kitchen_env()

result = eve.enter_environment(env)
print(f"  진입 결과: {result['env']}, 에피소드 #{result['episode']}")
print(f"  관찰: {result['observation']['summary']}")
print(f"  객체: {result['observation']['objects']}")

results.append(passed("환경 진입 성공",
                     result['env'] == '주방'))
results.append(passed("객체 인식",
                     '사과' in result['observation']['objects']
                     and '물' in result['observation']['objects']))
results.append(passed("위치 카테고리 활성",
                     '주방' in eve.sa.activations
                     or '주방' in result['observation']['categories']))


# ============================================================
# [2] 성공 행동 → 호르몬 보상 → 학습
# ============================================================
section("[2] 성공 행동 (사과 먹기)")
da_before = eve.hs.hormones['dopamine'].level
print(f"  도파민 before: {da_before:.3f}")

result = eve.act_in_env('먹다', '사과')
print(f"  행동 결과: {result['feedback']}")
print(f"  성공: {result['success']}")
print(f"  호르몬 효과: {result['hormone_effects']}")
print(f"  목표 달성: {result['goals_completed']}")

da_after = eve.hs.hormones['dopamine'].level
print(f"  도파민 after: {da_after:.3f}")

results.append(passed("성공 행동 인식",
                     result['success']))
results.append(passed("도파민 ↑",
                     da_after > da_before,
                     f"{da_before:.3f} → {da_after:.3f}"))
results.append(passed("배고픔 해소 목표 달성",
                     '배고픔 해소' in result['goals_completed']))

# 학습 확인 — '먹다' ↔ '만족' 연결됨 (SA._key 알파벳 정렬이라 get_weight 사용)
weight_eat_satisfy = eve.sa.get_weight('먹다', '만족')
results.append(passed("Hebbian: '먹다' ↔ '만족' 학습됨",
                     weight_eat_satisfy > 0,
                     f"weight={weight_eat_satisfy:.3f}"))


# ============================================================
# [3] 실패 행동 → 호르몬 처벌 → 회피 학습
# ============================================================
section("[3] 실패 행동 (의자 먹기)")
cort_before = eve.hs.hormones['cortisol'].level

result = eve.act_in_env('먹다', '의자')
print(f"  결과: {result['feedback']}")
print(f"  성공: {result['success']}")

cort_after = eve.hs.hormones['cortisol'].level

results.append(passed("실패 행동 — success=False",
                     not result['success']))
results.append(passed("코르티솔 ↑ (처벌)",
                     cort_after > cort_before,
                     f"{cort_before:.3f} → {cort_after:.3f}"))

# 회피 학습 — '의자' ↔ '실패' 연결
weight_chair_fail = eve.sa.get_weight('의자', '실패')
results.append(passed("회피 학습: '의자' ↔ '실패'",
                     weight_chair_fail > 0,
                     f"weight={weight_chair_fail:.3f}"))


# ============================================================
# [4] 인과 그래프 학습
# ============================================================
section("[4] 인과 학습 (CG)")
# CG 상태 확인 — '먹다' → '만족' 또는 '배부름' 등록됐나
# CG 상태 확인 — '먹다' → 결과 카테고리 등록
try:
    eat_children = eve.cg.children('먹다')
    print(f"  '먹다'의 자식 (CG): {eat_children}")
    results.append(passed("CG에 '먹다 → X' 인과 등록",
                         bool(eat_children) and len(eat_children) > 0,
                         f"children={dict(eat_children)}"))
except Exception as e:
    print(f"  CG 조회 에러: {e}")
    results.append(passed("CG 학습", False, str(e)))


# ============================================================
# [5] 자율 행동 (suggest_action)
# ============================================================
section("[5] 자율 행동 — EVE가 스스로 행동 제안")
# 새 환경 — 신선
env2 = make_kitchen_env()
eve2 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
eve2.enter_environment(env2)

print(f"  현재 욕구: 배고픔={env2.state['배고픔']}, 목마름={env2.state['목마름']}")
suggestion = eve2.suggest_action_in_env()
print(f"  EVE 제안: {suggestion}")

results.append(passed("자율 행동 제안",
                     suggestion is not None,
                     f"{suggestion}"))
if suggestion:
    # 제안 실행
    action, target = suggestion
    r = eve2.act_in_env(action, target)
    print(f"  실행 결과: {r['feedback']}")
    results.append(passed("제안 행동 성공",
                         r['success']))

# 두 번째 제안 — 이번엔 목마름이 우선이어야
suggestion2 = eve2.suggest_action_in_env()
print(f"  2차 제안: {suggestion2}")
if suggestion2:
    action, target = suggestion2
    r = eve2.act_in_env(action, target)
    print(f"  실행: {r['feedback']}")
    results.append(passed("2차 제안 성공",
                         r['success']))


# ============================================================
# [6] 학습 효과 영속성 — exit 후 잔존
# ============================================================
section("[6] exit 후 학습 잔존")
# eve2의 SA 가중치 보존 확인
weight_eat_before_exit = eve2.sa.get_weight('먹다', '만족')
exit_stats = eve2.exit_environment()
weight_eat_after_exit = eve2.sa.get_weight('먹다', '만족')

print(f"  exit stats: {exit_stats}")
print(f"  weight '먹다↔만족': {weight_eat_before_exit:.3f} → {weight_eat_after_exit:.3f}")

results.append(passed("exit 정상 작동",
                     'env' in exit_stats and exit_stats.get('env') == '주방'))
results.append(passed("학습 영속 (SA 가중치 잔존)",
                     weight_eat_after_exit > 0,
                     f"weight={weight_eat_after_exit:.3f}"))
results.append(passed("성공률 측정",
                     'success_rate' in exit_stats,
                     f"rate={exit_stats.get('success_rate'):.2f}"))


# ============================================================
# [7] 회귀 안전 — 메인 EVE 대화 그대로
# ============================================================
section("[7] 회귀 — 환경 종료 후 일반 대화 정상")
r1 = eve2.say("배고파")
r2 = eve2.say("어제 우리 뭐 했지?")
print(f"  '배고파' → '{r1['response']}'")
print(f"  '어제 뭐 했지?' → '{r2['response']}'")

results.append(passed("종료 후 일반 say 작동",
                     bool(r1['response']) and bool(r2['response'])))
results.append(passed("패턴 분류 정상",
                     r1['pattern'] == 'physical_first_person'))


# ============================================================
# [8] 새 환경 진입 — 학습 누적되는지
# ============================================================
section("[8] 두 번째 환경 진입 — 학습 누적")
env3 = make_kitchen_env()
eve2.enter_environment(env3)

# 이번에도 사과 먹기 — 더 많이 강화돼야
weight_before = eve2.sa.get_weight('먹다', '만족')
eve2.act_in_env('먹다', '사과')
weight_after = eve2.sa.get_weight('먹다', '만족')

results.append(passed("학습 누적 (가중치 증가)",
                     weight_after > weight_before,
                     f"{weight_before:.3f} → {weight_after:.3f}"))

# 에피소드 카운트 증가
results.append(passed("에피소드 카운트 ↑",
                     eve2._env_adapter.episode_count == 2,
                     f"episode={eve2._env_adapter.episode_count}"))

eve2.exit_environment()


# ============================================================
# [9] 시연 — 풀 에피소드 (배고픔 → 사과 먹기 → 만족)
# ============================================================
section("[9] 시연: 풀 에피소드 (자율 행동 시퀀스)")
eve3 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
env4 = make_kitchen_env()
eve3.enter_environment(env4)

print(f"  초기: 배고픔={env4.state['배고픔']}, 목마름={env4.state['목마름']}")
print(f"  초기 도파민: {eve3.hs.hormones['dopamine'].level:.3f}")
print(f"  초기 코르티솔: {eve3.hs.hormones['cortisol'].level:.3f}")

# 5번 자율 행동
for step in range(5):
    sug = eve3.suggest_action_in_env()
    if sug is None:
        print(f"  [{step+1}] 제안 없음 (목표 달성된 듯)")
        break
    action, target = sug
    r = eve3.act_in_env(action, target)
    state = r['env_state']
    print(f"  [{step+1}] {action}({target}) → 성공={r['success']}, "
          f"배고픔={state.get('배고픔'):.2f}, 목마름={state.get('목마름'):.2f}")
    if r['goals_completed']:
        print(f"      ★ 목표 달성: {r['goals_completed']}")

print(f"  최종 도파민: {eve3.hs.hormones['dopamine'].level:.3f}")
print(f"  최종 코르티솔: {eve3.hs.hormones['cortisol'].level:.3f}")
print(f"  최종 feeling: {eve3.nl.feeling_to_text()}")

stats = eve3.exit_environment()
print(f"  학습 페어: {stats['learned_pairs']}, 인과: {stats['learned_causal']}")
print(f"  성공률: {stats['success_rate']:.2f}")

results.append(passed("시연 — 양 목표 달성",
                     len(stats['goals_completed']) >= 2,
                     f"goals={stats['goals_completed']}"))
results.append(passed("시연 — 호르몬 양성 변화",
                     eve3.hs.hormones['dopamine'].level >= 0.30,
                     f"DA={eve3.hs.hormones['dopamine'].level:.3f}"))


# ============================================================
# 요약
# ============================================================
print()
print("=" * 70)
total = len(results)
pass_count = sum(results)
print(f"  검증: {pass_count} / {total}")
print("=" * 70)

if pass_count == total:
    print("\n🎉 v37 기호적 가상공간 통과!")
    print()
    print("학습 메커니즘 작동 확인:")
    print("  ✅ 환경 진입/관찰 (카테고리 활성)")
    print("  ✅ 성공 → 도파민 ↑ → SA Hebbian 강화")
    print("  ✅ 실패 → 코르티솔 ↑ → 회피 학습")
    print("  ✅ CG 인과 학습 (먹다 → X)")
    print("  ✅ 자율 행동 (suggest_action)")
    print("  ✅ 학습 영속 (exit 후 가중치 잔존)")
    print("  ✅ 학습 누적 (재진입 시 가중치 ↑)")
    print("  ✅ 회귀 안전 (메인 say 정상)")
    print()
    print("✨ EVE는 이제 가상 공간에서 행동/학습 가능 ✨")
else:
    print(f"\n⚠ {total - pass_count}개 실패")
    sys.exit(1)
