import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

# CG 인터페이스 확인
print("CG type:", type(eve.cg).__name__)
print("CG methods:", [m for m in dir(eve.cg) if not m.startswith('_')][:20])
print()

# 시드 후 상태
if hasattr(eve.cg, 'edges'):
    print("CG edges count:", len(eve.cg.edges) if hasattr(eve.cg.edges, '__len__') else 'N/A')
if hasattr(eve.cg, 'graph'):
    print("CG graph:", eve.cg.graph)
if hasattr(eve.cg, 'causal_links'):
    print("CG causal_links count:", len(eve.cg.causal_links))
    # 처음 몇 개만
    if eve.cg.causal_links:
        for i, link in enumerate(list(eve.cg.causal_links)[:5] if hasattr(eve.cg.causal_links, '__iter__') else eve.cg.causal_links[:5]):
            print(f"  link[{i}]:", link)

# parents 직접 호출
print()
print("parents('자다'):", eve.cg.parents('자다'))
print("parents('자기'):", eve.cg.parents('자기'))
print("parents('수면'):", eve.cg.parents('수면'))
print("parents('피곤'):", eve.cg.parents('피곤'))
