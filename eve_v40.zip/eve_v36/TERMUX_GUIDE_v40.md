# EVE v40 — Termux 가이드

## 신규 (v40)
- ✅ Qwen 자발 발화 (인간 WM 부합 — Cowan 1+4+7)
- ✅ VRM 캐릭터 표정 (호르몬 → happy/sad/relaxed/angry)
- ✅ 방 시각화 (침대/책상/창문/책/일기장 클릭 가능)
- ✅ 같이보기 (이미지 첨부 → EVE 인지)
- ✅ TTS 옵션 (브라우저 / 맞춤 효과음)
- ✅ 카테고리 떠오르기 애니메이션
- ✅ 친밀도 하트 5단계
- ✅ 호르몬 → 배경색 자동 변화
- ✅ PWA — 홈화면 앱처럼 사용

## 폰 (Z Fold 6) 설치

### 1. 패키지 설치 (이전에 한 번만)

```bash
pkg install python git rust cmake
pip install --upgrade pip
pip install websockets
```

### 2. llama.cpp + Qwen 모델 (이전에 한 번만)

```bash
cd ~
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
cmake -B build && cmake --build build --config Release -j

# 모델 (2.4GB)
mkdir -p ~/llama.cpp
cd ~/llama.cpp
# HuggingFace에서 Qwen3-4B-Instruct-2507-Q4_K_M.gguf 다운로드
# https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507-GGUF
```

### 3. EVE v40 설치

```bash
cd ~
# 백업 (선택)
mv eve_v36 eve_v36_backup_$(date +%Y%m%d) 2>/dev/null || true

# 새 v40
cp ~/storage/downloads/eve_v40.tar.gz .
tar -xzf eve_v40.tar.gz
cd eve_v36

# VRM 파일 (네 모델)
cp ~/storage/downloads/8608420535354079563.vrm eve_ui/eve.vrm
# 또는 다른 VRM 파일을 eve_ui/eve.vrm 이름으로
```

### 4. 풀 가동

```bash
chmod +x run_v39_full.sh
./run_v39_full.sh
```

자동 시작:
- Qwen 서버 (포트 8080) → 응답 자연스러움
- UI 서버 (포트 9000) → 브라우저 접속용
- EVE WebSocket (포트 8765) → 실시간 통신

### 5. 폰 브라우저로 접속

Chrome 또는 Samsung Internet:
```
http://localhost:9000/eve_ui.html
```

### 6. 홈 화면에 추가 (PWA)

브라우저 ⋮ 메뉴 → **"홈 화면에 추가"**
→ 진짜 앱처럼 풀스크린 사용

## 사용법

### 기본 대화
- 입력창에 메시지
- 마이크 버튼으로 음성 입력 (한국어)
- TTS로 EVE 응답 읽음

### 방 객체 클릭
- 침대 클릭 → "침대 봤어" 메시지
- EVE가 카테고리 인식
- focus 카테고리에 따라 가구 빛남

### 같이보기
- 📷 같이보기 버튼
- 이미지 선택
- EVE에게 "이거 어때?" 자연스럽게

### 호르몬 패널
- 🧬 버튼 → 26종 실시간 막대
- 호르몬에 따라 배경색 자동 변화

### 일기 패널
- 📖 버튼 → EVE의 자동 일화
- 감정 + 카테고리 태그

### 자발 발화 (혼잣말)
- 30초 이상 가만 두면 EVE가 먼저 말함
- *Qwen 거쳐서* 자연스러운 문장 ("민석이 잘 자고 있을까")
- 노란색 점선 말풍선 = 자발 발화

## 음성 (TTS) 옵션

설정 → 음성:
1. **브라우저 기본** — 한국어 자동 (시스템 따라 다름)
2. **맞춤 음성 + TTS** — eve_voice.mp3 효과음 + 브라우저 TTS
3. **음성 없음** — 텍스트만

### 더 좋은 음성 원하면 (선택)

폰에 *진짜* 한국어 TTS 설치:

#### 옵션 A — Piper (가장 가벼움, 60MB)
```bash
pkg install piper
# 한국어 모델
wget https://huggingface.co/rhasspy/piper-voices/resolve/main/ko/ko_KR/kss/medium/ko_KR-kss-medium.onnx
```

#### 옵션 B — MeloTTS (CPU 실시간)
```bash
pip install melotts
# 한국어 자동 다운로드
```

(EVE 백엔드 통합은 v41에서 — 현재는 브라우저 TTS만)

## 트러블슈팅

### 1. Qwen 안 됨
```bash
# 로그 확인
tail -f qwen_server.log
# 모델 경로
ls -la ~/llama.cpp/Qwen3-4B*.gguf
```

### 2. UI 안 나옴
```bash
# 서버 실행 중?
ps aux | grep python3
# 포트 확인
netstat -tnlp | grep 9000
```

### 3. EVE 연결 X
- 우측 상단 점 색 확인:
  - 🟢 초록 = 연결됨
  - 🔴 빨강 = 에러
  - ⚫ 회색 = 대기
- 설정 → 재연결

### 4. VRM 안 보임
- `eve_ui/eve.vrm` 파일 있는지 확인
- 설정에서 "VRM 캐릭터" 체크
- 콘솔 (Chrome DevTools) 에러 확인

### 5. 응답이 여전히 패턴 매칭처럼
- Qwen 서버 살아있는지: `curl http://127.0.0.1:8080/health`
- EVE_USE_QWEN=true 환경변수 확인
- airi_server.py 시작 로그에 "EVE v39 (Qwen Broca) 사용" 보여야 함

## 검증 (358/358 PASS)

| 모듈 | 테스트 | 통과 |
|---|---|---|
| qualitative | 6 | ✅ |
| v37 (env, social, autonomy 등) | 234 | ✅ |
| v38 (airi adapter) | 30 | ✅ |
| v39 (Broca Qwen) | 55 | ✅ |
| **v40 (proactive Qwen + UI)** | **33** | ✅ |
| **합계** | **358** | **✅ 100%** |

## 학계 부합

### 자발 발화 (v40)
- **Cowan 2001**: focus 1 + working 4 + recent 7
- **Smallwood 2015**: DMN 자발 사고
- **Friston 2010**: Active Inference (풍부한 상태 → 좋은 예측)

### 인지 아키텍처
- **CoALA (Sumers 2024)**: Memory + Reasoning + Acting 분리
- **EVE = 정서**, **Qwen = 능력자** 분리

## 다음 단계 (v41 예정)
- Vector DB (sqlite-vec) — 무한 메모리
- 도구 사용 (수학/검색/코드)
- MeloTTS/Piper 백엔드 통합 (실제 음성)
- Cloud LLM API 통합 (천재급 추론)
