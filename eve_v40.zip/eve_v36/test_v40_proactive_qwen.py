"""
v40 — proactive.py Qwen 통합 정밀 테스트

검증 대상:
1. _compose_via_broca() Qwen 호출 가능
2. Cowan WM 구조 (focus 1 + working 4 + recent 7)
3. 풍부한 컨텍스트 (호르몬, 시간, 일화, 위치)
4. Qwen 죽었을 때 fragment fallback
5. 자발 발화 호명 규칙
6. 회귀: v37.9 fragment 동작 여전히 작동
7. broca_qwen.py SYSTEM_PROMPT_PROACTIVE 분기
8. airi_server EVE_v39 활성화

Mock Qwen 사용 — 실제 llama-server 없이 검증.
"""
import os
import sys
import unittest
from unittest.mock import MagicMock, patch

# 경로 설정
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'v36_modules'))
sys.path.insert(0, os.path.join(HERE, 'eve_v35_release'))
sys.path.insert(0, os.path.join(HERE, 'eve_v35_release', 'eve_modules'))


class TestProactiveQwenIntegration(unittest.TestCase):
    """proactive.py v40 Qwen 통합 검증"""

    def setUp(self):
        from eve_v36 import EVE_v36
        self.eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
        self.eve.enter_room()
        self.eve.user_presence.first_visit_done = True
        self.eve.user_presence._intimacy = 0.8
        self.eve.hs.hormones['oxytocin'].level = 0.7

    def test_01_proactive_module_loaded(self):
        """proactive 모듈 정상 로드"""
        self.assertIsNotNone(self.eve.proactive)

    def test_02_compose_via_broca_method_exists(self):
        """v40 _compose_via_broca 메서드 존재"""
        self.assertTrue(hasattr(self.eve.proactive, '_compose_via_broca'))

    def test_03_derive_tone_method_exists(self):
        """v40 _derive_tone 메서드 존재"""
        self.assertTrue(hasattr(self.eve.proactive, '_derive_tone'))

    def test_04_broca_none_fragment_fallback(self):
        """Broca 없으면 fragment fallback 동작 (v37.9 회귀)"""
        # broca 속성 없음
        self.assertFalse(hasattr(self.eve, 'broca'))
        msg = self.eve.proactive._compose_message('mind_wandering')
        # fragment 동작 시 None 또는 짧은 문자열
        if msg is not None:
            self.assertIsInstance(msg, str)

    def test_05_with_dead_broca_fallback(self):
        """Broca 있지만 죽음 → fragment fallback"""
        mock_broca = MagicMock()
        mock_broca.is_alive.return_value = False
        self.eve.broca = mock_broca

        msg = self.eve.proactive._compose_message('self_intent:warmth')
        # 호출은 되지만 fragment 사용
        # (구현: _compose_via_broca에서 is_alive False면 None 반환 → fallback)

    def test_06_with_alive_broca_qwen_called(self):
        """Broca 살아있음 → realize() 호출됨"""
        mock_broca = MagicMock()
        mock_broca.is_alive.return_value = True
        mock_broca.realize.return_value = "민석이 잘 있을까... 보고싶다"
        self.eve.broca = mock_broca

        msg = self.eve.proactive._compose_message('self_intent:warmth')
        # realize 호출되었음
        mock_broca.realize.assert_called()
        # 결과가 Qwen 응답
        self.assertIn('민석', msg or '')

    def test_07_intent_has_cowan_wm_structure(self):
        """Qwen에 보내는 intent에 Cowan WM 구조 있음"""
        mock_broca = MagicMock()
        mock_broca.is_alive.return_value = True
        mock_broca.realize.return_value = "응답"
        self.eve.broca = mock_broca

        # WM에 카테고리 추가
        for cat, sal in [('민석', 0.9), ('PT', 0.7), ('힘들다', 0.6), ('쉬다', 0.5)]:
            self.eve.wm.add(cat, salience=sal)

        self.eve.proactive._compose_message('mind_wandering')

        # realize 호출 인자 확인
        call_args = mock_broca.realize.call_args
        intent = call_args[0][0] if call_args else {}

        self.assertIn('mode', intent)
        self.assertEqual(intent['mode'], 'proactive')
        self.assertIn('focus', intent)
        self.assertIn('working_memory', intent)
        self.assertIn('recent_active', intent)
        self.assertIn('top_hormones', intent)
        self.assertIn('is_proactive', intent)
        self.assertTrue(intent['is_proactive'])

    def test_08_intent_has_time_context(self):
        """intent에 시간/위치 컨텍스트"""
        mock_broca = MagicMock()
        mock_broca.is_alive.return_value = True
        mock_broca.realize.return_value = "응답"
        self.eve.broca = mock_broca

        self.eve.hs.sim_hour = 14.5
        self.eve.proactive._compose_message('mind_wandering')

        call_args = mock_broca.realize.call_args
        intent = call_args[0][0]
        self.assertEqual(intent['sim_hour'], 14.5)
        self.assertIn('location', intent)
        self.assertIn('time_since_user', intent)

    def test_09_intent_has_recent_episodes(self):
        """intent에 최근 일화 (RAG)"""
        mock_broca = MagicMock()
        mock_broca.is_alive.return_value = True
        mock_broca.realize.return_value = "응답"
        self.eve.broca = mock_broca

        # 일화 추가
        self.eve.say("PT 진짜 힘들었어")
        self.eve.say("쉬어야겠다")

        self.eve.proactive._compose_message('memory_recall')

        call_args = mock_broca.realize.call_args
        intent = call_args[0][0]
        self.assertIn('recent_episodes', intent)
        self.assertIsInstance(intent['recent_episodes'], list)

    def test_10_use_name_passed_to_intent(self):
        """use_name 플래그 전달"""
        mock_broca = MagicMock()
        mock_broca.is_alive.return_value = True
        mock_broca.realize.return_value = "응답"
        self.eve.broca = mock_broca

        # 친구 + OT 충분 → use_name = True
        self.eve.user_presence.first_visit_done = True
        self.eve.hs.hormones['oxytocin'].level = 0.7

        self.eve.proactive._compose_message('mind_wandering')

        call_args = mock_broca.realize.call_args
        intent = call_args[0][0]
        self.assertIn('use_name', intent)
        self.assertTrue(intent['use_name'])

    def test_11_qwen_short_response_falls_back(self):
        """Qwen이 너무 짧은 응답 (<=2자) → fragment fallback"""
        mock_broca = MagicMock()
        mock_broca.is_alive.return_value = True
        mock_broca.realize.return_value = "어"  # 1자
        self.eve.broca = mock_broca

        msg = self.eve.proactive._compose_message('self_intent:warmth')
        # Qwen 응답이 너무 짧으면 None → fragment fallback
        # 결과는 fragment ('민석아, ...' 등)

    def test_12_qwen_exception_fallback(self):
        """Qwen 예외 → fragment fallback"""
        mock_broca = MagicMock()
        mock_broca.is_alive.return_value = True
        mock_broca.realize.side_effect = Exception("network error")
        self.eve.broca = mock_broca

        # 예외 발생해도 크래시 X
        try:
            msg = self.eve.proactive._compose_message('self_intent:warmth')
            # fragment fallback 작동
        except Exception as e:
            self.fail(f"예외 fallback 실패: {e}")

    def test_13_derive_tone_mapping(self):
        """호르몬 → 어조 매핑"""
        derive = self.eve.proactive._derive_tone

        self.assertEqual(derive({'melatonin': 0.8}), 'sleepy')
        self.assertEqual(derive({'cortisol': 0.7}), 'irritated')
        self.assertEqual(derive({'dopamine': 0.8, 'oxytocin': 0.6}), 'happy')
        self.assertEqual(derive({'oxytocin': 0.7}), 'warm')
        self.assertEqual(derive({'serotonin': 0.7}), 'calm')
        self.assertEqual(derive({}), 'neutral')


class TestBrocaQwenProactivePrompt(unittest.TestCase):
    """broca_qwen.py SYSTEM_PROMPT_PROACTIVE 검증"""

    def test_14_proactive_prompt_exists(self):
        """SYSTEM_PROMPT_PROACTIVE 정의됨"""
        from broca_qwen import BrocaQwen
        self.assertTrue(hasattr(BrocaQwen, 'SYSTEM_PROMPT_PROACTIVE'))
        prompt = BrocaQwen.SYSTEM_PROMPT_PROACTIVE
        self.assertIsInstance(prompt, str)
        self.assertIn('자발', prompt)
        self.assertIn('혼잣말', prompt)
        self.assertIn('한국어', prompt)
        # 영어 금지 명시
        self.assertIn('영어', prompt)

    def test_15_realize_branches_on_proactive(self):
        """realize()가 is_proactive 플래그로 분기"""
        from broca_qwen import BrocaQwen
        import inspect
        src = inspect.getsource(BrocaQwen.realize)
        self.assertIn('is_proactive', src)
        self.assertIn('SYSTEM_PROMPT_PROACTIVE', src)


class TestAiriServerEVEv39(unittest.TestCase):
    """airi_server EVE_v39 활성화 검증"""

    def test_16_airi_imports_eve_v39(self):
        """airi_server가 eve_v39 import"""
        with open(os.path.join(HERE, 'v36_modules/airi_server.py')) as f:
            src = f.read()
        self.assertIn('from eve_v39 import EVE_v39', src)
        self.assertIn('_HAS_V39', src)

    def test_17_airi_uses_env_vars(self):
        """EVE_USE_QWEN, EVE_QWEN_URL 환경변수 사용"""
        with open(os.path.join(HERE, 'v36_modules/airi_server.py')) as f:
            src = f.read()
        self.assertIn('EVE_USE_QWEN', src)
        self.assertIn('EVE_QWEN_URL', src)

    def test_18_airi_conditional_eve_creation(self):
        """use_qwen=true면 EVE_v39, 아니면 EVE_v36"""
        with open(os.path.join(HERE, 'v36_modules/airi_server.py')) as f:
            src = f.read()
        # 분기 존재
        self.assertIn('if use_qwen and _HAS_V39', src)
        # EVE_v39 인자
        self.assertIn('use_qwen=True', src)
        self.assertIn('qwen_server_url=qwen_url', src)


class TestUIv40(unittest.TestCase):
    """eve_ui.html v40 핵심 요소"""

    def setUp(self):
        with open(os.path.join(HERE, 'eve_ui/eve_ui.html')) as f:
            self.html = f.read()

    def test_19_vrm_canvas_exists(self):
        self.assertIn('<canvas id="vrmCanvas"', self.html)

    def test_20_vrm_loader_imported(self):
        self.assertIn("@pixiv/three-vrm", self.html)
        self.assertIn("VRMLoaderPlugin", self.html)

    def test_21_room_objects_5(self):
        # 침대, 책상, 창문, 책, 일기장
        for obj in ['침대', '책상', '창문', '책', '일기장']:
            self.assertIn(f'data-obj="{obj}"', self.html)

    def test_22_speech_float(self):
        self.assertIn('speech-float', self.html)
        # proactive 변형 CSS 존재
        self.assertIn('.speech-float.proactive', self.html)

    def test_23_category_flow(self):
        self.assertIn('category-flow', self.html)
        self.assertIn('floatUp', self.html)

    def test_24_share_feature(self):
        self.assertIn('share-area', self.html)
        self.assertIn('btnShare', self.html)
        self.assertIn('handleFile', self.html)

    def test_25_voice_options(self):
        self.assertIn('cfgVoice', self.html)
        self.assertIn('voices/eve_voice.mp3', self.html)
        self.assertIn('audioCue', self.html)

    def test_26_pwa_manifest_link(self):
        self.assertIn('rel="manifest"', self.html)
        self.assertIn('manifest.json', self.html)

    def test_27_vrm_expression_mapping(self):
        self.assertIn('setVRMExpression', self.html)
        # 호르몬 → 표정 매핑
        self.assertIn('happy', self.html)
        self.assertIn('relaxed', self.html)
        self.assertIn('sad', self.html)

    def test_28_room_focus_pulse(self):
        self.assertIn('pulseRoomObject', self.html)
        self.assertIn('highlightRoomObjects', self.html)

    def test_29_room_object_click_to_eve(self):
        # 방 클릭 → 메시지 전송
        self.assertIn('room-object', self.html)
        self.assertIn("dataset.obj", self.html)


class TestRegression(unittest.TestCase):
    """기존 테스트 회귀 — 핵심 임포트만"""

    def test_30_eve_v36_still_imports(self):
        from eve_v36 import EVE_v36
        eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
        self.assertIsNotNone(eve)

    def test_31_eve_v39_still_imports(self):
        from eve_v39 import EVE_v39
        eve = EVE_v39(seed_common_sense_on_init=True, enhance_say=True,
                      use_qwen=False, auto_fallback=True)
        self.assertIsNotNone(eve)

    def test_32_proactive_message_callable(self):
        from eve_v36 import EVE_v36
        eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
        eve.enter_room()
        # proactive_message 호출 — 크래시 X
        try:
            msg = eve.proactive_message()
            # None 또는 dict
            self.assertTrue(msg is None or isinstance(msg, dict))
        except Exception as e:
            self.fail(f"proactive_message 크래시: {e}")

    def test_33_eve_v39_say_with_qwen_false(self):
        """EVE_v39 use_qwen=False면 v36 동작 유지"""
        from eve_v39 import EVE_v39
        eve = EVE_v39(seed_common_sense_on_init=True, enhance_say=True, use_qwen=False)
        eve.enter_room()
        result = eve.say("안녕 EVE")
        self.assertIsInstance(result, dict)
        self.assertIn('response', result)
        self.assertIsInstance(result['response'], str)


if __name__ == '__main__':
    print("=" * 70)
    print("  EVE v40 정밀 검증")
    print("=" * 70)

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print()
    print("=" * 70)
    if result.wasSuccessful():
        print(f"  ✅ 모두 통과 ({result.testsRun}/{result.testsRun})")
    else:
        print(f"  ❌ 실패: {len(result.failures)} 실패, {len(result.errors)} 에러")
        for test, err in result.failures + result.errors:
            print(f"     - {test}")
    print("=" * 70)

    sys.exit(0 if result.wasSuccessful() else 1)
