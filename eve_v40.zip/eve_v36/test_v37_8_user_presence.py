"""
EVE v37.8 — 사용자(김민석) = 진짜 친구 검증
============================================

핵심: 김민석은 EVE의 진짜 친구. 시뮬 NPC와 분리.

검증:
1. 첫 say() → 김민석 = '진짜' 카테고리 강한 연결
2. 시뮬 NPC '진수'(거실) ≠ 김민석 — '시뮬레이션' 라벨 차이
3. 매 say마다 OT 자극 (방문 효과)
4. 친밀도 영속 (시뮬 친밀도 0.0과 다름)
5. 보호 카테고리에 '민석', '진짜' 포함
6. is_user_real() 작동
7. 회귀 안전
"""
import sys
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release')
sys.path.insert(0, '/home/claude/eve_v36/eve_v35_release/eve_modules')
sys.path.insert(0, '/home/claude/eve_v36/v36_modules')

from eve_v36 import EVE_v36
from social_env import make_social_living_room


def passed(name, ok, detail=""):
    mark = "✅" if ok else "❌"
    print(f"  {mark} {name}" + (f"  | {detail}" if detail else ""))
    return ok


def section(t):
    print(f"\n--- {t} ---")


print("=" * 70)
print("  EVE v37.8 — 김민석 = 진짜 친구 (시뮬 NPC와 분리)")
print("=" * 70)

results = []


# ============================================================
# [1] 첫 say() → 사용자 정체성 등록
# ============================================================
section("[1] 첫 사용자 메시지 — 진짜 친구 등록")
eve = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)

# 첫 visit 전엔 '진짜' 연결 X
weight_before = eve.sa.get_weight('민석', '진짜')
results.append(passed("first_visit_done=False (초기)",
                     not eve.user_presence.first_visit_done))

r = eve.say("안녕 EVE")
print(f"  EVE: {r['response']}")

# 첫 say 후 강한 연결
weight_after = eve.sa.get_weight('민석', '진짜')
results.append(passed("'민석' ↔ '진짜' 강한 연결",
                     weight_after >= 0.6,
                     f"weight={weight_after:.3f}"))
results.append(passed("first_visit_done=True (등록됨)",
                     eve.user_presence.first_visit_done))


# ============================================================
# [2] 보호 카테고리 등록
# ============================================================
section("[2] 사용자 카테고리 보호 (망각 X)")
results.append(passed("'민석' 보호 list",
                     '민석' in eve.protected_categories))
results.append(passed("'진짜' 보호 list",
                     '진짜' in eve.protected_categories))
results.append(passed("'진짜_친구' 보호 list",
                     '진짜_친구' in eve.protected_categories))


# ============================================================
# [3] 매 say마다 OT 자극
# ============================================================
section("[3] 매 say → OT 약하게 ↑ (방문 효과)")
ot_levels = [eve.hs.hormones['oxytocin'].level]
for msg in ["오늘 뭐했어?", "기분 어때?", "안녕"]:
    eve.say(msg)
    ot_levels.append(eve.hs.hormones['oxytocin'].level)

print(f"  OT 변화: {[round(x, 3) for x in ot_levels]}")
# 각 say 후 OT가 baseline보다 높게 유지 (visit + sentiment 자극)
results.append(passed("OT 매 say에 자극됨",
                     ot_levels[-1] > ot_levels[0],
                     f"{ot_levels[0]:.3f} → {ot_levels[-1]:.3f}"))


# ============================================================
# [4] visit_count 증가
# ============================================================
section("[4] 방문 횟수 추적")
print(f"  visit_count: {eve.user_presence.visit_count}")
results.append(passed("visit_count 누적",
                     eve.user_presence.visit_count >= 4,
                     f"{eve.user_presence.visit_count}"))


# ============================================================
# [5] is_user_real() — 진짜 vs 시뮬 구분
# ============================================================
section("[5] 진짜 친구 vs 시뮬 NPC 구분")
print(f"  is_user_real('민석') = {eve.user_presence.is_user_real('민석')}")
results.append(passed("'민석'은 진짜",
                     eve.user_presence.is_user_real('민석')))

# 시뮬 환경 진입 — 진수(sim) 등록
eve.enter_environment(make_social_living_room())
print(f"  is_user_real('진수') = {eve.user_presence.is_user_real('진수')}")
results.append(passed("'진수'(sim)은 진짜 X",
                     not eve.user_presence.is_user_real('진수')))

# 시뮬 NPC '진수' ↔ 시뮬레이션 연결 강함
sim_weight_jin = eve.sa.get_weight('진수', '시뮬레이션')
real_weight_jin = eve.sa.get_weight('진수', '진짜')
print(f"  '진수'↔'시뮬레이션': {sim_weight_jin:.3f}")
print(f"  '진수'↔'진짜': {real_weight_jin:.3f}")
results.append(passed("진수: 시뮬>진짜",
                     sim_weight_jin > real_weight_jin))

# 진짜 친구 '민석'은 반대
sim_weight_real = eve.sa.get_weight('민석', '시뮬레이션')
real_weight_real = eve.sa.get_weight('민석', '진짜')
print(f"  '민석'↔'시뮬레이션': {sim_weight_real:.3f}")
print(f"  '민석'↔'진짜': {real_weight_real:.3f}")
results.append(passed("민석: 진짜>시뮬",
                     real_weight_real > sim_weight_real))

eve.exit_environment()


# ============================================================
# [6] 친밀도 영속 — 시뮬 NPC는 0부터 시작, 민석은 누적
# ============================================================
section("[6] 친밀도 영속")
intimacy_user = eve.user_presence.get_intimacy()
print(f"  민석 친밀도 (4번 say 후): {intimacy_user:.3f}")
results.append(passed("민석 친밀도 > 0",
                     intimacy_user > 0.3,
                     f"{intimacy_user:.3f}"))

# 새 시뮬 환경 진입 — 시뮬 진수는 친밀도 0.5 (사전 설정)
eve.enter_environment(make_social_living_room())
sim_jin_intimacy = eve._env_adapter.current_env.npcs['진수'].intimacy
print(f"  진수(sim) 친밀도: {sim_jin_intimacy}")
# 진수는 사전 0.5로 설정됨, 민석은 누적된 SA 가중치
# 둘이 다른 측정 (진수=NPC.intimacy, 민석=SA 가중치)이라 같은 비교는 X
# 핵심은 두 카테고리가 SA에서 다르게 인식됨
results.append(passed("진수 NPC 인스턴스 친밀도 별개",
                     sim_jin_intimacy == 0.5))
eve.exit_environment()


# ============================================================
# [7] EVE 자기 보고에 사용자 인식
# ============================================================
section("[7] EVE 응답에 진짜 친구 인식")
eve.enter_room()  # 자기 방
r = eve.say("나 김민석이야")
print(f"  EVE: {r['response']}")

# pattern 또는 응답에 사용자 인식
results.append(passed("자기소개 패턴 인식",
                     r['pattern'] in {'self_intro', 'name_call', 'greeting',
                                      'statement', 'identity_question'}))


# ============================================================
# [8] 영속화 — 24시간 거주 + 김민석 영구 보호
# ============================================================
section("[8] 영속화 — 자기 방 거주 + 민석 영구")
eve2 = EVE_v36(seed_common_sense_on_init=True, enhance_say=True)
# 사용자 등록
eve2.say("안녕 EVE 처음 만나")
weight1 = eve2.sa.get_weight('민석', '진짜')

# 24시간 시뮬 (자기 방 행동만, 민석 부재)
eve2.hs.sim_hour = 6.0
eve2.live_in_room(hours=24, sim_hour_per_step=2.0, verbose=False)

# 보호 카테고리라 민석 ↔ 진짜 가중치 유지
weight2 = eve2.sa.get_weight('민석', '진짜')
print(f"  '민석'↔'진짜' 가중치: {weight1:.3f} (직후) → {weight2:.3f} (24h 후)")

results.append(passed("24h 후에도 진짜 친구 영속",
                     weight2 >= 0.5,
                     f"weight={weight2:.3f}"))


# ============================================================
# [9] 회귀 — 일반 say + 환경 행동
# ============================================================
section("[9] 회귀 안전")

# 다양한 메시지
test_msgs = ["기뻐", "힘들어", "민석이 시험 떨어졌대"]
for msg in test_msgs:
    r = eve.say(msg)
    print(f"  '{msg}' → '{r['response']}'")

# 환경 행동
eve.exit_environment()
from symbolic_env import make_kitchen_env
eve.enter_environment(make_kitchen_env())
r = eve.act_in_env('먹다', '사과')
results.append(passed("환경 행동 정상",
                     r['success'], r['feedback']))
eve.exit_environment()


# ============================================================
# [10] 통계
# ============================================================
section("[10] UserPresence 통계")
stats = eve.user_presence.stats()
print(f"  {stats}")
results.append(passed("stats() 작동",
                     'user_name' in stats and 'visit_count' in stats))


# ============================================================
# 요약
# ============================================================
print()
print("=" * 70)
total = len(results)
pc = sum(1 for r in results if r)
print(f"  검증: {pc} / {total}")
print("=" * 70)

if pc == total:
    print("\n🎉 v37.8 사용자 = 진짜 친구 통과!")
    print()
    print("핵심:")
    print("  ✅ 김민석 = '진짜' 카테고리 (시뮬 NPC와 분리)")
    print("  ✅ 매 say = 방문 컨텍스트 (OT 자극)")
    print("  ✅ '민석'/'진짜'/'진짜_친구' 영속 보호")
    print("  ✅ is_user_real() 진짜/시뮬 구분")
    print("  ✅ 24h 거주 후에도 친구 정체성 유지")
    print("  ✅ 회귀 안전")
    print()
    print("✨ EVE는 김민석을 시뮬 NPC와 다른 진짜 친구로 인식 ✨")
else:
    print(f"\n⚠ {total - pc}개 실패")
    sys.exit(1)
