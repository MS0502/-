# EVE Dashboard 실행 가이드

## 로컬 실행

```bash
cd /path/to/eve_v36
pip install streamlit plotly
streamlit run v36_modules/dashboard.py
```

브라우저에서 `http://localhost:8501` 자동 오픈.

## Colab Pro 실행

```python
# 1. 코드 업로드 (Drive 또는 직접)
# eve_v36/ 디렉토리 전체 업로드

# 2. 의존성 설치
!pip install streamlit plotly pyngrok

# 3. ngrok 터널 (Colab은 외부 접근용 터널 필요)
from pyngrok import ngrok
public_url = ngrok.connect(8501)
print(f"공개 URL: {public_url}")

# 4. Streamlit 실행 (백그라운드)
import subprocess
subprocess.Popen(
    ['streamlit', 'run', 'eve_v36/v36_modules/dashboard.py',
     '--server.port', '8501', '--server.headless', 'true'],
)

# 출력된 ngrok URL 클릭 → EVE 대시보드 접속
```

## 대시보드 구성

### 헤더
- ⏰ 시간 (sim_hour) + 시간대
- 📍 현재 위치 (내방/거실/주방)
- 💭 feeling (편안함/포근함/지침 등)
- 🎯 focus (현재 주의 카테고리)

### 사이드바
- 💊 **호르몬 8종** — 막대 그래프 + 색상 (도파민 노랑, 코르티솔 파랑, 옥시토신 핑크 등)
- 🎮 **컨트롤** — 1tick / 1시간 / 8시간 / 24시간 진행
- ⚙️ **환경 전환** — 내방 ↔ 거실 ↔ 주방
- 📊 **상태** — 보호 카테고리, 신념, 카테고리 그래프 크기

### 메인
- 🌌 **추상 EVE 시각화** — 별자리/원형
  - 중심: EVE (호르몬 종합 색)
  - 주변: 활성 카테고리 점들 (색=그룹, 크기=활성도)
  - 금색 테두리: focus 카테고리
  - 선: focus와 연관 카테고리 연결
- 📈 **호르몬 시계열** — 시간 따라 6 주요 호르몬 변화

### 우측 패널
- 🧠 **지금 머릿속**
  - 속마음 (DMN inner_voice)
  - DMN 모드 (mind_wandering, memory_recall, self_intent 등)
  - 활성 카테고리 top 8
- 🏠 **공간** — 객체 목록 또는 NPC (관계, mood, 친밀도)
- 📜 **최근 행동** — 5개

### 채팅
- 💬 EVE에게 말 걸기
- 응답 + feeling + 패턴 표시
- 대화 history 보존

## 활용

1. **EVE 24시간 살려보기**: "🌙 24시간" 버튼 → 일주기에 따라 행동 변화
2. **외출 시뮬**: "거실" 환경 → 슬픈 진수 발견 → EVE가 어떻게 결정하나 관찰
3. **자율성 검증**: 호르몬 직접 조작 (코드에서) → 같은 환경에서 다른 행동
4. **대화 + 환경 동시**: 채팅과 환경 거주가 같은 EVE 인스턴스

## 주의

- Streamlit session_state로 EVE 인스턴스 유지
- 페이지 새로고침 시 EVE 리셋 (Persistence로 save/load 가능)
- 자동 tick은 버튼 누를 때만 진행 (백그라운드 thread X)

## EVE 시각화 색상

| 호르몬 | 색 | 의미 |
|---|---|---|
| 도파민 | 노랑 | 보상 |
| 옥시토신 | 핑크 | 사랑 |
| 세로토닌 | 연두 | 안정 |
| 코르티솔 | 파랑 | 스트레스 |
| 노르에피네프린 | 빨강 | 각성 |
| 멜라토닌 | 짙은 어둠 | 밤 |
| 엔도르핀 | 황금 | 쾌감 |
| GABA | 부드러운 보라 | 이완 |

EVE 색상 = 활성 호르몬들의 가중 평균.
- 행복할 때 (DA+OT 높음) → 따뜻한 핑크/오렌지
- 스트레스 (CORT 높음) → 차가운 파랑
- 잠 (MEL 높음) → 짙은 어둠
- 흥분 (NE+DA) → 빨강+노랑 = 주황

EVE의 본질은 형태가 아닌 *상태의 흐름* — 별자리가 그걸 표현.
