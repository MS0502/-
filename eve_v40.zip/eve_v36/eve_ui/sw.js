/**
 * EVE PWA Service Worker
 * 오프라인 캐싱 + 네트워크 폴백
 */

const CACHE_NAME = 'eve-v1';
const ASSETS = [
  './eve_ui.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon.png',
  './favicon.ico',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // WebSocket / API 호출은 캐싱 X
  if (event.request.url.includes('ws:') || event.request.url.includes('wss:')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).catch(() => {
        // 오프라인 → 메인 페이지
        if (event.request.mode === 'navigate') {
          return caches.match('./eve_ui.html');
        }
      });
    })
  );
});
