#!/usr/bin/env python3
"""
EVE UI 정적 HTTP 서버 (가벼운 PWA 호스팅)
- airi_server.py(WebSocket)와 별개로 UI 파일 제공
- PWA는 HTTPS or localhost가 필요해 같은 폰 localhost로 접속

사용:
  python3 eve_ui_server.py
  → http://localhost:9000/eve_ui.html

옵션:
  PORT=9000  (기본)
  HOST=0.0.0.0  (같은 wifi 다른 기기 접속용)
"""
import os
import sys
import http.server
import socketserver
from pathlib import Path

HERE = Path(__file__).resolve().parent
PORT = int(os.environ.get('PORT', '9000'))
HOST = os.environ.get('HOST', '0.0.0.0')

os.chdir(HERE)


class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # PWA 필수 헤더
        self.send_header('Service-Worker-Allowed', '/')
        self.send_header('Cache-Control', 'no-cache')
        # CORS (다른 폰에서 접속 시)
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def log_message(self, fmt, *args):
        # 깔끔한 로그
        print(f"[ui] {self.address_string()} - {fmt % args}")


class ReuseAddrTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


def main():
    print("=" * 50)
    print("  EVE UI 서버")
    print(f"  디렉터리: {HERE}")
    print(f"  주소: http://{HOST}:{PORT}/eve_ui.html")
    print(f"  같은 폰: http://localhost:{PORT}/eve_ui.html")
    print("=" * 50)

    if not (HERE / 'eve_ui.html').exists():
        print("⚠️  eve_ui.html 없음 — 같은 디렉터리에 있어야 함")
        sys.exit(1)

    try:
        with ReuseAddrTCPServer((HOST, PORT), Handler) as httpd:
            print(f"\n서버 시작. Ctrl+C로 종료.")
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n종료")
    except OSError as e:
        if 'Address already in use' in str(e):
            print(f"\n❌ 포트 {PORT} 사용 중. PORT={PORT+1} 으로 다시 시도")
        else:
            raise


if __name__ == '__main__':
    main()
