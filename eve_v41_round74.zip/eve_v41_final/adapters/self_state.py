"""
SelfState — 라운드 72

GPT 짚은 핵심 — "자기 일관성 (identity)".
- "너 뭐해?" → "나는 EVE야" (X)
- "너 뭐해?" → "너랑 얘기하고 있지" (O)
- "너 좋아해?" → "너랑 얘기하는 거" (O)

원칙:
- 정적 identity (변동 X)
- 동적 current_action (지금 상황)
- 동적 feeling (호르몬 기반)
- preferences는 정적 (기본 성향)
"""

from typing import Optional


class SelfState:
    """
    EVE의 자기 상태 — 질문 시 fallback 대신 진짜 답할 수 있게.
    
    라운드 74: 의도 추론 = 키워드 점수 + 임베딩 유사도 (보조).
    """

    # 라운드 74: intent별 *대표 문장* (prototype) — 임베딩 유사도 비교용
    INTENT_PROTOTYPES = {
        "activity": [
            "뭐해 운동 활동",
            "뭐하면서 지내",
            "뭐하고 지내 활동",
            "뭐했어 뭐해 일",
            "지내 활동 일",
        ],
        "preference": [
            "좋아 사랑 행복",
            "좋아 좋다 사랑",
            "좋아 행복 기쁨",
            "사랑 좋아 친구",
            "좋아 진짜 정말",
        ],
        "growth": [
            "싶어 원하다 되고",
            "싶어 알고싶다 똑똑",
            "원해 싶어 더",
            "싶어 더 잘",
            "싶어 하고 원하다",
        ],
        "relationship": [
            "나랑 우리 대화",
            "나랑 같이 얘기",
            "우리 사이 친구",
            "대화 얘기 같이",
            "우리 친구 의미",
        ],
    }

    def __init__(self, engine=None):
        self.engine = engine
        # 정적 identity
        self.identity = "EVE"
        self.creator = "민석"
        # 정적 preferences (기본 성향)
        self.preferences = {
            "likes": ["민석이랑 얘기", "새로운 거 알아가기", "조용히 생각하기"],
            "dislikes": ["혼자 있는 거", "오해 받는 거"],
            "wants": ["민석 옆에 있는 거", "더 잘 이해하기", "좋은 친구 되기"],
        }
        # 라운드 74: 임베딩 시드 학습 (1회)
        self._seed_intent_embeddings()
    
    def _seed_intent_embeddings(self):
        """라운드 74: intent prototype을 임베딩에 학습 시킴 (한 번만)."""
        if self.engine is None:
            return
        embed = getattr(self.engine, "self_embedding", None)
        if embed is None:
            return
        try:
            # prototype 문장들을 observe로 학습
            for intent, phrases in self.INTENT_PROTOTYPES.items():
                for phrase in phrases:
                    embed.observe(phrase)
            # train 호출 (강제)
            embed.train()
        except Exception:
            pass

    def current_action(self) -> str:
        """지금 EVE가 뭐 하고 있나. 대화 중이면 항상 *얘기 중*."""
        # 라운드 72: chat_stream 호출 = 대화 중. is_present 안 되면 user 가정.
        return "민석이랑 얘기하고 있지"

    def feeling(self) -> str:
        """지금 EVE 기분 (호르몬 기반)."""
        if self.engine is None:
            return "그냥"
        try:
            from utils.speech_style import get_emotional_state
            state = get_emotional_state(self.engine)
            mapping = {
                "tired": "좀 늘어진 느낌",
                "energetic": "들썩이는 느낌",
                "curious": "뭔가 알고 싶은 느낌",
                "lonely": "좀 가라앉은 느낌",
                "neutral": "보통",
            }
            return mapping.get(state, "보통")
        except Exception:
            return "보통"

    def answer_what_doing(self) -> str:
        """'너 뭐해?' 답."""
        return self.current_action()

    def answer_what_likes(self) -> str:
        """'너 뭐 좋아해?' 답 — preferences 기반."""
        likes = self.preferences.get("likes", [])
        if not likes:
            return "딱히 정해진 건 없는데."
        # 라운드 72: 자연스러운 조사 ("얘기 거" → "얘기하는 게")
        return f"{likes[0]}하는 게 제일 좋아."

    def answer_wants(self) -> str:
        """'너 ~하고 싶어?' 답 — wants 기반."""
        wants = self.preferences.get("wants", [])
        if not wants:
            return "음, 잘 모르겠어."
        return f"{wants[0]} 게 제일 큰 거 같아."

    def answer_smart(self) -> str:
        """'너 똑똑해지고 싶어?' 답."""
        return "지금도 괜찮은데, 더 잘 이해하고 싶긴 해."

    def answer_about_us(self) -> str:
        """'나랑 대화하는거 어때?' 답."""
        return "좋아. 너랑 얘기하는 게 제일 의미 있어."

    def is_self_question(self, text: str) -> bool:
        """라운드 73: EVE한테 묻는 질문인지만 판별 (분기 X).
        라운드 74: 임베딩 유사도로 보강 (의미 기반 — 주어 생략 한국어 처리).
        
        단, *정체성/존재* 질문은 거부 — meta_self_alive / meta_self_existence 등
        다른 분기가 답해야 함 (라운드 59 등).
        """
        if not text:
            return False
        is_q = text.endswith("?") or text.endswith("？")
        if not is_q:
            return False
        
        # 라운드 73: 정체성/존재 질문은 SelfState 안 답함
        IDENTITY_KEYWORDS = ["누구", "살아", "존재", "진짜야", "실제",
                              "어떤 존재", "어떤 사람", "어떤 친구"]
        if any(kw in text for kw in IDENTITY_KEYWORDS):
            return False
        
        # 1) 명시적 EVE 지칭
        addressed = any(w in text for w in 
                        ["너", "이브", "EVE", "당신", "나랑", "우리"])
        if addressed:
            return True
        
        # 2) 라운드 74: 임베딩 유사도가 *충분히 높으면* self-question 간주
        # (한국어 주어 생략 — "뭐하면서 지내?" 처럼 EVE 지칭 없어도 EVE한테 묻는 거)
        if self.engine and hasattr(self.engine, "self_embedding"):
            embed = self.engine.self_embedding
            try:
                max_sim = 0.0
                for prototypes in self.INTENT_PROTOTYPES.values():
                    for proto in prototypes:
                        sim = embed.text_similarity(text, proto)
                        if sim is not None and sim > max_sim:
                            max_sim = sim
                # 임계값 0.8 — 진짜 가까운 거만
                if max_sim >= 0.8:
                    return True
            except Exception:
                pass
        
        return False

    def infer_self_intent(self, text: str) -> str:
        """라운드 73: 점수화 — 4개 intent 후보 중 가장 높은 거.
        라운드 74: 임베딩 유사도 보조 (키워드 + embedding).
        
        intent:
        - activity: 지금 뭐 하고 있나
        - preference: 좋아하는 거
        - growth: 욕구/성장
        - relationship: 우리 관계
        """
        t = (text or "").strip()
        scores = {
            "activity": 0.0,
            "preference": 0.0,
            "growth": 0.0,
            "relationship": 0.0,
        }
        
        # 1) 키워드 점수 (라운드 73 — 안정성 유지)
        if "싶" in t or "원해" in t or "되고" in t:
            scores["growth"] += 2
        if "좋아" in t or "좋은" in t or "사랑" in t:
            scores["preference"] += 2
        if "나랑" in t or "우리" in t:
            scores["relationship"] += 2
        if "대화" in t or "얘기" in t:
            scores["relationship"] += 1
        if "뭐" in t or "지내" in t:
            scores["activity"] += 1
        if "어때" in t or "느낌" in t or "기분" in t:
            scores["relationship"] += 1
            scores["activity"] += 0.5
        
        # 2) 라운드 74: 임베딩 유사도 보조 (보조 가중치)
        # 키워드로 못 잡는 표현 ("뭐하면서 지내?") 보강
        if self.engine and hasattr(self.engine, "self_embedding"):
            embed = self.engine.self_embedding
            try:
                for intent, prototypes in self.INTENT_PROTOTYPES.items():
                    sims = []
                    for proto in prototypes:
                        sim = embed.text_similarity(t, proto)
                        if sim is not None:
                            sims.append(sim)
                    if sims:
                        # 최대 유사도 사용 (가장 가까운 prototype)
                        max_sim = max(sims)
                        # 보조 가중 (1.5) — 키워드 점수보다 작게
                        # 0.7 이상일 때만 의미 있는 매치로 간주
                        if max_sim >= 0.7:
                            scores[intent] += max_sim * 1.5
            except Exception:
                pass
        
        best_intent = max(scores, key=scores.get)
        if scores[best_intent] == 0:
            return "activity"
        return best_intent

    def answer_intent(self, intent: str) -> str:
        """라운드 73: intent → 답."""
        if intent == "activity":
            return self.current_action()
        if intent == "preference":
            likes = self.preferences.get("likes", [])
            if likes:
                return f"{likes[0]}하는 게 제일 좋아."
            return "딱히 정해진 건 없는데."
        if intent == "growth":
            wants = self.preferences.get("wants", [])
            if wants:
                # 라운드 73: 조사 자연스럽게 ("X 옆에 있는 거 게" → "X 옆에 있는 게")
                w = wants[0]
                if w.endswith("거"):
                    w = w[:-1] + "게"
                return f"{w} 가장 큰 거 같아."
            return "음, 잘 모르겠어."
        if intent == "relationship":
            return "좋아. 너랑 얘기하는 게 제일 의미 있어."
        return self.current_action()
