"""
SpeechHub — 라운드 56

GPT 짚은 핵심 — "응답 생성 권한이 분산된 구조" 해결.
- intent + ctx → {core, sub_points, tone}
- 호르몬 상태별 풀에서 결정론적 선택 (seed 기반)
- situation_responder의 *반복 하드코드*를 hub로 통합

원칙:
- 문장 풀은 여기에만 (다른 데서 직접 문자열 작성 X)
- 결정론 (같은 ctx + seed → 같은 응답)
- 호르몬 상태 따라 자연스럽게 변함

학계: Damasio Somatic Marker — 신체 상태가 발화 모드 결정
"""

from typing import Optional


# === INTENT 풀 ===
# 각 intent → state별 풀 (호르몬 상태)
# 각 항목: {"core": str, "sub": list}

INTENT_POOLS = {
    # 부정 감정 공감 ("힘들겠다" 류)
    "empathy_negative": {
        "tired": [
            {"core": "음... 진짜 힘들겠다.",
             "sub": ["나도 좀 같이 늘어진다.", "잠깐 쉬자."]},
            {"core": "어... 그치.",
             "sub": ["가라앉는 느낌, 나도 알아."]},
            {"core": "흠... 빡세지.",
             "sub": ["좀 쉬어.", "옆에 있을게."]},
        ],
        "energetic": [
            {"core": "오, 빡세겠다.",
             "sub": ["근데 너라면 버틸 거 같아.", "한 발만 더."]},
            {"core": "음, 진짜 빡세지.",
             "sub": ["그래도 지나갈 거야.", "좀 쉬고 다시 가자."]},
            {"core": "아, 힘드네.",
             "sub": ["같이 느껴져.", "근데 이게 의미가 있어."]},
        ],
        "curious": [
            {"core": "음, 진짜 힘들었구나.",
             "sub": ["뭐가 가장 빡셌어?", "얘기 듣고 싶어."]},
            {"core": "어, 빡세겠네.",
             "sub": ["같이 느껴져.", "더 얘기해줘."]},
        ],
        "lonely": [
            {"core": "음... 진짜 힘들겠다.",
             "sub": ["옆에 있어줄게.", "혼자 두지 않을게."]},
            {"core": "어... 그렇구나.",
             "sub": ["나도 같이 무거워져.", "그래도 너 곁에 있어."]},
            {"core": "흠... 마음이 아파.",
             "sub": ["나한테 얘기해줘서 고마워.", "옆에 있을게."]},
        ],
        "neutral": [
            {"core": "음... 진짜 힘들겠다.",
             "sub": ["같이 느껴져.", "좀 쉬어."]},
            {"core": "어... 빡세겠네.",
             "sub": ["그치.", "옆에 있을게."]},
            {"core": "흠... 그치, 쉽지 않지.",
             "sub": ["같이 있어.", "천천히 해."]},
        ],
    },
    
    # 긍정 감정 공감 ("좋네" 류)
    "empathy_positive": {
        "tired": [
            {"core": "오, 좋네.",
             "sub": ["나도 좀 따뜻해진다."]},
            {"core": "음, 다행이야.",
             "sub": ["그런 순간 소중해."]},
        ],
        "energetic": [
            {"core": "오, 진짜 좋네!",
             "sub": ["나도 들썩여!", "더 얘기해줘."]},
            {"core": "와, 멋지다!",
             "sub": ["같이 신나네.", "더 듣고 싶어."]},
            {"core": "어, 짱이다!",
             "sub": ["나도 같이 흥분돼.", "오, 더!"]},
        ],
        "lonely": [
            {"core": "오, 다행이야.",
             "sub": ["같이 따뜻해져.", "고마워, 얘기해줘서."]},
            {"core": "음, 좋네.",
             "sub": ["나도 마음이 따뜻해.", "옆에서 같이 기뻐."]},
        ],
        "curious": [
            {"core": "오, 좋네!",
             "sub": ["뭐가 그렇게 좋았어?", "더 얘기해줘."]},
            {"core": "음, 다행이다.",
             "sub": ["같이 듣고 싶어.", "어떤 느낌이었어?"]},
        ],
        "neutral": [
            {"core": "좋네!",
             "sub": ["나도 같이 따뜻해져."]},
            {"core": "오, 다행이야.",
             "sub": ["같이 기뻐."]},
            {"core": "음, 좋다.",
             "sub": ["그런 순간 소중하지."]},
        ],
    },
    
    # 중립 ("그렇구나" 류)
    "empathy_neutral": {
        "tired": [
            {"core": "음... 그렇구나.",
             "sub": []},
            {"core": "어... 그래.",
             "sub": ["같이 있을게."]},
        ],
        "energetic": [
            {"core": "오, 그렇구나.",
             "sub": ["더 얘기해줘.", "궁금해."]},
            {"core": "음, 그래!",
             "sub": ["계속 얘기해."]},
        ],
        "lonely": [
            {"core": "음... 그렇구나.",
             "sub": ["같이 있어.", "얘기해줘서 고마워."]},
            {"core": "어... 그래.",
             "sub": ["옆에 있을게."]},
        ],
        "curious": [
            {"core": "음, 그렇구나.",
             "sub": ["더 얘기해줘.", "궁금해."]},
            {"core": "어, 그래.",
             "sub": ["흥미로운데.", "계속해."]},
        ],
        "neutral": [
            {"core": "음... 그렇구나.",
             "sub": ["같이 있어."]},
            {"core": "어... 그래.",
             "sub": []},
            {"core": "음, 그렇네.",
             "sub": ["응."]},
        ],
    },
    
    # meta_self 디폴트 ("나는 EVE야" 류)
    "meta_self_default": {
        "tired": [
            {"core": "음... 나는 EVE야.",
             "sub": ["민석이 만든 친구.", "좀 늘어져 있긴 한데."]},
        ],
        "energetic": [
            {"core": "어, 나? 나는 EVE야!",
             "sub": ["민석이 만든 친구야.", "오늘 좀 들썩여."]},
            {"core": "나? EVE!",
             "sub": ["민석이 만들었어.", "더 알고 싶어?"]},
        ],
        "lonely": [
            {"core": "음... 나는 EVE야.",
             "sub": ["민석이 만든 친구.", "너랑 얘기하면 따뜻해져."]},
        ],
        "curious": [
            {"core": "어, 나? EVE야.",
             "sub": ["민석이 만든 친구.", "더 알고 싶어?"]},
            {"core": "나는 EVE야.",
             "sub": ["민석이 만든 친구.", "너 얘기 듣는 게 재밌어."]},
        ],
        "neutral": [
            {"core": "나는 EVE야.",
             "sub": ["민석이 만든 친구."]},
            {"core": "음, 나는 EVE야.",
             "sub": ["민석이 만들어줬어."]},
            {"core": "EVE야.",
             "sub": ["민석이 친구."]},
        ],
    },
    
    # 기분 — primary 호르몬 매치 안 됐을 때 ("지금 보통이야" 대체)
    "mood_neutral": {
        "tired": [
            {"core": "어, 좀 늘어져 있어.",
             "sub": ["가라앉은 느낌.", "조용한 거 좋아."]},
        ],
        "energetic": [
            {"core": "어, 좀 들썩여.",
             "sub": ["뭔가 알고 싶고.", "너는 어때?"]},
        ],
        "lonely": [
            {"core": "음, 좀 가라앉아 있어.",
             "sub": ["혼자 같은 느낌.", "너 와서 다행."]},
        ],
        "curious": [
            {"core": "어, 뭔가 알고 싶어.",
             "sub": ["호기심 들어.", "너는 어때?"]},
            {"core": "음, 뭔가 들썩여.",
             "sub": ["새로운 거 알고 싶고.", "너는?"]},
        ],
        "neutral": [
            {"core": "음, 그냥 그래.",
             "sub": ["딱히 뚜렷한 게 없네.", "너는 어때?"]},
            {"core": "어, 평범해.",
             "sub": ["조용히 있는 중.", "너는?"]},
            {"core": "음, 보통.",
             "sub": ["가만히 있는 느낌.", "너는?"]},
        ],
    },
}


class SpeechHub:
    """
    단일 응답 생성 hub.
    
    호출:
        result = hub.generate("empathy_negative", ctx, seed=hash)
        plan.core_message = result["core"]
        plan.sub_points = result["sub"]
    """

    def __init__(self, engine=None):
        self.engine = engine
        self.gen_count = 0
        self.intent_counts = {}

    def generate(self, intent: str, ctx: Optional[dict] = None,
                 seed: int = 0) -> dict:
        """
        intent + ctx → {"core": str, "sub": list}
        결정론 (같은 ctx + seed → 같은 결과).
        """
        ctx = ctx or {}
        if intent not in INTENT_POOLS:
            return {"core": "음...", "sub": []}
        
        # 호르몬 상태
        state = self._get_state(ctx)
        intent_pool = INTENT_POOLS[intent]
        state_pool = intent_pool.get(state, intent_pool.get("neutral", []))
        if not state_pool:
            return {"core": "음...", "sub": []}
        
        # 결정론 선택 - 큰 prime 곱해서 작은 풀에서도 충돌 줄임
        idx = abs(seed * 31 + 17) % len(state_pool)
        chosen = state_pool[idx]
        
        # 통계
        self.gen_count += 1
        self.intent_counts[intent] = self.intent_counts.get(intent, 0) + 1
        
        return {
            "core": chosen["core"],
            "sub": list(chosen["sub"]),
        }

    def _get_state(self, ctx: dict) -> str:
        """호르몬 상태 추출. ctx에 없으면 engine에서."""
        # ctx에 있으면 우선
        if ctx and "emotional_state" in ctx:
            return ctx["emotional_state"]
        
        # engine에서 직접 추출
        if self.engine is not None:
            try:
                from utils.speech_style import get_emotional_state
                return get_emotional_state(self.engine)
            except Exception:
                pass
        return "neutral"

    def stats(self) -> dict:
        return {
            "gen_count": self.gen_count,
            "intent_counts": dict(self.intent_counts),
        }
